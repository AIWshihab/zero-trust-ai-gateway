"""
Seed global preset models that are visible to every user.
Called once at startup — idempotent (skips if already present).
"""

from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.model import Model
from app.schemas import ModelType, RiskLevel, SensitivityLevel, ScanStatus


PRESET_MODELS = [
    {
        "name": "Mistral 7B Instruct",
        "description": "Open-source 7B parameter instruction-following model by Mistral AI. Available to all users.",
        "model_type": ModelType.HUGGINGFACE,
        "provider_name": "Mistral AI",
        "hf_model_id": "mistralai/Mistral-7B-Instruct-v0.3",
        "source_url": "https://huggingface.co/mistralai/Mistral-7B-Instruct-v0.3",
        "visibility": "global",
        "owner_user_id": None,
        "is_active": True,
        "scan_status": ScanStatus.COMPLETED,
        "risk_level": RiskLevel.LOW,
        "sensitivity_level": SensitivityLevel.LOW,
        "base_trust_score": 72.0,
        "base_risk_score": 28.0,
        "secured_risk_score": 14.0,
        "has_model_card": True,
        "supports_https": True,
        "requires_auth": False,
    },
    {
        "name": "GPT-4o Mini",
        "description": "OpenAI GPT-4o Mini — fast, cost-efficient OpenAI model. Uses the configured OPENAI_API_KEY. Available to all users.",
        "model_type": ModelType.OPENAI,
        "provider_name": "OpenAI",
        "hf_model_id": "gpt-4o-mini",
        "source_url": "https://platform.openai.com/docs/models/gpt-4o-mini",
        "visibility": "global",
        "owner_user_id": None,
        "is_active": True,
        "scan_status": ScanStatus.COMPLETED,
        "risk_level": RiskLevel.LOW,
        "sensitivity_level": SensitivityLevel.MEDIUM,
        "base_trust_score": 85.0,
        "base_risk_score": 15.0,
        "secured_risk_score": 8.0,
        "has_model_card": True,
        "supports_https": True,
        "requires_auth": True,
    },
]


async def seed_preset_models(db: AsyncSession) -> None:
    PATCH_FIELDS = {"base_trust_score", "base_risk_score", "secured_risk_score", "scan_status", "is_active"}

    for spec in PRESET_MODELS:
        result = await db.execute(
            select(Model).where(
                Model.name == spec["name"],
                Model.visibility == "global",
                Model.owner_user_id.is_(None),
            )
        )
        existing = result.scalar_one_or_none()
        if existing is not None:
            changed = False
            for field in PATCH_FIELDS:
                if field in spec and getattr(existing, field, None) is None:
                    setattr(existing, field, spec[field])
                    changed = True
            if changed:
                existing.updated_at = datetime.now(timezone.utc)
            continue

        now = datetime.now(timezone.utc)
        db.add(Model(**spec, created_at=now, updated_at=now))

    await db.commit()
