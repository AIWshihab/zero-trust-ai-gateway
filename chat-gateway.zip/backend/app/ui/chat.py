from app.ui.common import CYBER_UI_CSS, CYBER_UI_JS


CHAT_HTML = """
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Secure AI Inference — Zero Trust AI Gateway</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/github-dark.min.css" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/marked/9.1.6/marked.min.js"></script>
  <style>
    :root {
      color-scheme: dark;
      --bg: #070706;
      --panel: rgba(18, 18, 16, .94);
      --panel-2: rgba(29, 26, 22, .94);
      --line: rgba(255, 178, 77, .34);
      --line-strong: rgba(255, 178, 77, .58);
      --text: #fff7ea;
      --muted: #d4c0a4;
      --soft: #aab3bf;
      --amber: #ffb13b;
      --red: #ff4d3d;
      --green: #78e08f;
      --cyan: #8ce9ff;
      --blue: #6fb0ff;
      --ink: #080604;
      font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      min-height: 100vh;
      color: var(--text);
      background:
        linear-gradient(118deg, rgba(255,255,255,.035) 0 1px, transparent 1px 70px),
        radial-gradient(circle at 18% 10%, rgba(255, 159, 28, .25), transparent 28%),
        radial-gradient(circle at 92% 8%, rgba(140, 233, 255, .12), transparent 30%),
        linear-gradient(140deg, #070706 0%, #15110d 45%, #2b1207 82%, #070706 100%);
      overflow: hidden;
    }
    body::before {
      content: "";
      position: fixed;
      inset: 0;
      pointer-events: none;
      background-image:
        linear-gradient(rgba(255,241,213,.07) 2px, transparent 2px),
        linear-gradient(90deg, rgba(255,241,213,.07) 2px, transparent 2px),
        repeating-linear-gradient(105deg, transparent 0 28px, rgba(255,255,255,.065) 29px 31px);
      background-size: 116px 64px, 116px 64px, 220px 220px;
      opacity: .5;
      mask-image: linear-gradient(to bottom, #000, transparent 90%);
    }
    .app {
      position: relative;
      z-index: 1;
      height: 100vh;
      display: grid;
      grid-template-columns: 310px minmax(0, 1fr) 320px;
      gap: 12px;
      padding: 14px;
    }
    .panel {
      border: 2px solid var(--ink);
      border-radius: 7px;
      background: var(--panel);
      box-shadow: 6px 6px 0 rgba(0,0,0,.72), 0 22px 70px rgba(0,0,0,.34);
      overflow: hidden;
      min-height: 0;
      position: relative;
    }
    .panel::after {
      content: "";
      position: absolute;
      inset: 0;
      pointer-events: none;
      background:
        linear-gradient(120deg, rgba(255,255,255,.07), transparent 28%, transparent 78%, rgba(255,255,255,.035)),
        repeating-linear-gradient(-12deg, transparent 0 19px, rgba(255,159,28,.05) 20px 22px);
      opacity: .7;
    }
    .inner { position: relative; z-index: 1; height: 100%; }
    .sidebar .inner, .inspector .inner {
      display: flex;
      flex-direction: column;
      gap: 12px;
      padding: 13px;
      min-height: 0;
    }
    .brand {
      display: grid;
      gap: 5px;
      padding-bottom: 8px;
      border-bottom: 2px solid rgba(255,178,77,.22);
    }
    .eyebrow { color: var(--amber); text-transform: uppercase; letter-spacing: .12em; font-weight: 950; font-size: 11px; }
    h1 {
      margin: 0;
      font-size: 25px;
      line-height: 1;
      text-transform: uppercase;
      text-shadow: 3px 3px 0 #000, 5px 5px 0 rgba(244, 123, 32, .34);
    }
    h2 {
      margin: 0;
      color: var(--amber);
      font-size: 13px;
      text-transform: uppercase;
      letter-spacing: .1em;
      text-shadow: 2px 2px 0 #000;
    }
    .muted { color: var(--soft); font-size: 12px; line-height: 1.42; }
    a, button {
      border: 2px solid #050403;
      border-radius: 7px;
      padding: 10px 11px;
      color: #170b04;
      background: linear-gradient(135deg, #ffd164, #ff8128 54%, #ef3f20);
      box-shadow: 4px 4px 0 rgba(0,0,0,.72);
      font-weight: 900;
      text-decoration: none;
      cursor: pointer;
      font: inherit;
      transition: transform .16s ease, filter .16s ease, opacity .16s ease;
    }
    a:hover, button:hover { transform: translate(-1px, -2px); filter: brightness(1.08); }
    button:disabled { opacity: .55; cursor: wait; transform: none; }
    .secondary, a.secondary { background: rgba(255, 241, 213, .08); color: var(--text); border-color: rgba(255, 178, 77, .48); }
    .danger { color: #ffd6d6; background: rgba(255,77,61,.18); border-color: rgba(255,77,61,.44); }
    .row { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
    label { display: grid; gap: 6px; color: #dce5f1; font-weight: 850; font-size: 12px; }
    input, textarea, select {
      width: 100%;
      border: 2px solid rgba(255, 178, 77, .34);
      border-radius: 7px;
      background: rgba(8, 6, 4, .82);
      color: var(--text);
      padding: 10px 11px;
      font: inherit;
      outline: none;
    }
    textarea { resize: none; line-height: 1.48; }
    input:focus, textarea:focus, select:focus { border-color: var(--amber); box-shadow: 0 0 0 3px rgba(255, 159, 28, .16); }
    .sessions {
      display: grid;
      gap: 8px;
      overflow: auto;
      min-height: 100px;
      padding-right: 2px;
    }
    .session {
      text-align: left;
      color: var(--text);
      background: rgba(0,0,0,.28);
      border-color: rgba(255,178,77,.28);
      box-shadow: 3px 3px 0 rgba(0,0,0,.45);
      min-height: 64px;
    }
    .session.active { border-color: var(--amber); background: rgba(255,159,28,.14); }
    .session small { display: block; margin-top: 4px; color: var(--soft); font-weight: 750; }
    .chat {
      display: grid;
      grid-template-rows: auto minmax(0, 1fr) auto;
      min-height: 0;
    }
    .chat-head {
      position: relative;
      z-index: 1;
      display: grid;
      grid-template-columns: minmax(0, 1fr) auto;
      gap: 12px;
      align-items: center;
      padding: 13px;
      border-bottom: 2px solid rgba(255,178,77,.22);
    }
    .chat-title { min-width: 0; }
    .chat-title strong { display: block; font-size: 18px; overflow-wrap: anywhere; }
    .pill {
      display: inline-flex;
      align-items: center;
      gap: 7px;
      border: 2px solid #050403;
      border-radius: 999px;
      padding: 7px 9px;
      color: #fff0d5;
      background: rgba(0,0,0,.36);
      box-shadow: 3px 3px 0 rgba(0,0,0,.62);
      font-size: 12px;
      font-weight: 900;
      white-space: nowrap;
      transition: box-shadow .22s ease, border-color .22s ease, background .22s ease, opacity .22s ease;
    }
    .pill.fx-block { border-color: rgba(251,113,133,.72); box-shadow: 0 0 20px rgba(251,113,133,.35); animation: fxPulse .5s ease 2; }
    .pill.fx-allow { border-color: rgba(52,211,153,.72); box-shadow: 0 0 18px rgba(52,211,153,.28); animation: fxFade .25s ease; }
    .pill.fx-challenge { border-color: rgba(251,191,36,.72); box-shadow: 0 0 20px rgba(251,191,36,.35); animation: fxFlicker .45s ease; }
    .dot { width: 8px; height: 8px; border-radius: 50%; background: var(--green); box-shadow: 0 0 16px var(--green); }
    .dot.bad { background: var(--red); box-shadow: 0 0 16px var(--red); }
    .messages {
      position: relative;
      z-index: 1;
      overflow: auto;
      min-height: 0;
      padding: 18px;
      display: flex;
      flex-direction: column;
      gap: 12px;
    }
    .empty {
      margin: auto;
      max-width: 640px;
      text-align: center;
      color: #ffe9c5;
      display: grid;
      gap: 10px;
    }
    .empty strong {
      font-size: clamp(28px, 5vw, 54px);
      line-height: .96;
      text-transform: uppercase;
      text-shadow: 4px 4px 0 #000, 7px 7px 0 rgba(244,123,32,.34);
    }
    .bubble {
      width: min(820px, 92%);
      border: 2px solid rgba(255,178,77,.24);
      border-radius: 8px;
      padding: 12px;
      background: rgba(0,0,0,.30);
      box-shadow: 4px 4px 0 rgba(0,0,0,.42);
      word-break: break-word;
    }
    .bubble.user {
      align-self: flex-end;
      background: linear-gradient(135deg, rgba(255,159,28,.22), rgba(255,255,255,.04));
      border-color: rgba(255,178,77,.42);
    }
    .bubble.assistant { align-self: flex-start; }
    .bubble.system {
      align-self: center;
      width: min(720px, 94%);
      color: #ffe1df;
      border-color: rgba(255,77,61,.42);
      background: rgba(255,77,61,.10);
    }
    .bubble-head {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 10px;
      margin-bottom: 8px;
      color: var(--amber);
      font-size: 12px;
      font-weight: 950;
      text-transform: uppercase;
      letter-spacing: .08em;
    }
    .bubble-actions { display: flex; gap: 6px; align-items: center; }
    .action-btn {
      font-size: 11px;
      padding: 4px 8px;
      border-radius: 5px;
      background: rgba(255,241,213,.08);
      color: var(--soft);
      border-color: rgba(255,178,77,.32);
      box-shadow: 2px 2px 0 rgba(0,0,0,.5);
      font-weight: 800;
    }
    .bubble-content {
      line-height: 1.6;
      white-space: pre-wrap;
      word-break: break-word;
    }
    .bubble.assistant .bubble-content { white-space: normal; }
    /* Markdown body styles */
    .markdown-body p { margin: 0 0 10px; }
    .markdown-body p:last-child { margin-bottom: 0; }
    .markdown-body ul, .markdown-body ol { margin: 6px 0 10px 20px; padding: 0; }
    .markdown-body li { margin-bottom: 4px; }
    .markdown-body h1, .markdown-body h2, .markdown-body h3,
    .markdown-body h4, .markdown-body h5, .markdown-body h6 {
      margin: 12px 0 6px;
      color: var(--amber);
      font-weight: 900;
      line-height: 1.2;
    }
    .markdown-body h1 { font-size: 18px; }
    .markdown-body h2 { font-size: 15px; }
    .markdown-body h3, .markdown-body h4 { font-size: 13px; }
    .markdown-body strong { color: var(--text); font-weight: 900; }
    .markdown-body em { color: var(--muted); }
    .markdown-body a { color: var(--cyan); background: none; border: none; box-shadow: none; padding: 0; font-weight: 600; }
    .markdown-body blockquote {
      margin: 8px 0;
      padding: 8px 12px;
      border-left: 3px solid rgba(255,178,77,.5);
      background: rgba(255,178,77,.06);
      border-radius: 0 6px 6px 0;
      color: var(--muted);
    }
    .markdown-body table {
      width: 100%;
      border-collapse: collapse;
      margin: 8px 0;
      font-size: 12px;
    }
    .markdown-body th, .markdown-body td {
      border: 1px solid rgba(255,178,77,.24);
      padding: 6px 10px;
      text-align: left;
    }
    .markdown-body th { background: rgba(255,178,77,.1); color: var(--amber); font-weight: 900; }
    .markdown-body code {
      background: rgba(0,0,0,.5);
      border: 1px solid rgba(255,178,77,.24);
      border-radius: 4px;
      padding: 1px 5px;
      font-family: "JetBrains Mono", "Fira Code", "Cascadia Code", monospace;
      font-size: 0.88em;
      color: var(--cyan);
    }
    /* Code blocks */
    .code-block {
      margin: 10px 0;
      border: 2px solid rgba(255,178,77,.24);
      border-radius: 7px;
      overflow: hidden;
      background: #0d1117;
    }
    .code-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 6px 12px;
      background: rgba(255,178,77,.08);
      border-bottom: 1px solid rgba(255,178,77,.18);
    }
    .code-lang { font-size: 11px; color: var(--amber); font-weight: 900; text-transform: uppercase; letter-spacing: .08em; }
    .copy-btn {
      font-size: 11px;
      padding: 3px 8px;
      border-radius: 4px;
      background: rgba(255,241,213,.1);
      color: var(--soft);
      border: 1px solid rgba(255,178,77,.3);
      box-shadow: none;
      font-weight: 800;
    }
    .copy-btn:hover { background: rgba(255,241,213,.18); transform: none; }
    .code-block pre {
      margin: 0;
      padding: 12px;
      overflow-x: auto;
      background: transparent;
      border: none;
      border-radius: 0;
      font-family: "JetBrains Mono", "Fira Code", monospace;
      font-size: 13px;
      line-height: 1.5;
    }
    .code-block pre code { background: transparent; border: none; padding: 0; color: inherit; font-size: inherit; }
    .markdown-body .code-block code { background: none; border: none; padding: 0; }
    /* Decision badge inline */
    .decision-badge {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      margin-top: 10px;
      padding: 5px 10px;
      border-radius: 999px;
      font-size: 11px;
      font-weight: 900;
      letter-spacing: .06em;
      border: 1px solid;
      text-transform: uppercase;
      cursor: default;
    }
    .decision-badge.badge-allow { color: #78e08f; border-color: rgba(120,224,143,.5); background: rgba(120,224,143,.1); }
    .decision-badge.badge-block { color: #ff4d3d; border-color: rgba(255,77,61,.5); background: rgba(255,77,61,.1); }
    .decision-badge.badge-challenge { color: #ffb13b; border-color: rgba(255,177,59,.5); background: rgba(255,177,59,.1); }
    .decision-badge.badge-pending { color: var(--soft); border-color: rgba(170,179,191,.3); background: rgba(170,179,191,.06); }
    /* Streaming cursor */
    .stream-cursor {
      display: inline-block;
      width: 2px;
      height: 1em;
      background: var(--amber);
      margin-left: 2px;
      vertical-align: text-bottom;
      animation: blink .9s ease infinite;
    }
    @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0} }
    .composer {
      position: relative;
      z-index: 1;
      display: grid;
      grid-template-columns: minmax(0, 1fr) auto;
      gap: 10px;
      padding: 13px;
      border-top: 2px solid rgba(255,178,77,.22);
      background: rgba(0,0,0,.18);
    }
    .composer textarea { min-height: 54px; max-height: 170px; }
    .send-stack { display: grid; gap: 8px; align-content: end; min-width: 124px; }
    .card {
      border: 2px solid rgba(255,178,77,.24);
      border-radius: 7px;
      padding: 10px;
      background: rgba(0,0,0,.24);
    }
    .metric-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; }
    .metric { border: 2px solid rgba(255,178,77,.2); border-radius: 7px; padding: 9px; background: rgba(0,0,0,.24); min-height: 70px; }
    .metric b { display: block; font-size: 19px; margin-top: 5px; }
    .status-card {
      border: 2px solid rgba(255,178,77,.26);
      border-radius: 7px;
      padding: 10px;
      background: rgba(0,0,0,.22);
      display: grid;
      gap: 5px;
    }
    .status-card.ready { border-color: rgba(120,224,143,.42); }
    .status-card.warn { border-color: rgba(255,178,77,.58); }
    .status-card.bad { border-color: rgba(255,77,61,.48); background: rgba(255,77,61,.08); }
    .status-card strong { color: var(--text); }
    .status-card small { color: var(--soft); line-height: 1.35; }
    pre {
      margin: 0;
      white-space: pre-wrap;
      word-break: break-word;
      min-height: 110px;
      max-height: 270px;
      overflow: auto;
      border: 2px solid rgba(255,178,77,.24);
      border-radius: 7px;
      padding: 10px;
      background: rgba(8,6,4,.82);
      color: #fff1d5;
      font-size: 12px;
      line-height: 1.45;
    }
    .quick-grid { display: grid; gap: 8px; }
    .quick-grid button { text-align: left; color: var(--text); background: rgba(255,241,213,.08); border-color: rgba(255,178,77,.36); }
    .mini-bars { display: grid; gap: 8px; margin-top: 8px; }
    .bar { display:grid; grid-template-columns: 92px 1fr 38px; gap: 7px; align-items:center; color: var(--soft); font-size: 11px; }
    .track { height: 8px; border-radius:999px; background: rgba(255,255,255,.08); overflow:hidden; }
    .fill { height:100%; border-radius:999px; background: linear-gradient(90deg, var(--green), var(--amber), var(--red)); }
    .fill.safe { background: linear-gradient(90deg, #22c55e, #16a34a); }
    .fill.mid { background: linear-gradient(90deg, #fbbf24, #f59e0b); }
    .fill.risky { background: linear-gradient(90deg, #fb7185, #ef4444); }
    .flow {
      margin-top: 10px;
      border: 1px solid rgba(255,255,255,.12);
      border-radius: 10px;
      padding: 8px;
      background: rgba(0,0,0,.22);
      font-size: 12px;
      color: var(--soft);
      line-height: 1.45;
    }
    .trace-toggle { margin-top: 8px; width: 100%; }
    .trace-collapsible { display: none; margin-top: 8px; }
    .trace-collapsible.open { display: block; }
    @media (max-width: 1120px) {
      .app { grid-template-columns: 260px minmax(0, 1fr); }
      .inspector { display: none; }
    }
    @media (max-width: 780px) {
      body { overflow: auto; }
      .app { height: auto; min-height: 100svh; grid-template-columns: 1fr; padding: 10px; gap: 10px; }
      .sidebar { order: 1; }
      .chat { order: 2; min-height: 70svh; }
      .inspector { display: flex !important; order: 3; }
      .inspector .inner { gap: 10px; }
      .composer { grid-template-columns: 1fr; }
      .send-stack { grid-template-columns: repeat(2, 1fr); min-width: 0; }
      .chat-head { grid-template-columns: 1fr; gap: 8px; }
      .chat-head .row { flex-wrap: wrap; gap: 6px; }
      .sidebar .row:first-of-type {
        overflow-x: auto;
        flex-wrap: nowrap;
        -webkit-overflow-scrolling: touch;
        padding-bottom: 4px;
      }
      .sidebar .row:first-of-type a,
      .sidebar .row:first-of-type button { flex-shrink: 0; font-size: 11px; padding: 8px 10px; }
    }
    @media (max-width: 420px) {
      .app { padding: 8px; gap: 8px; }
      .bubble { width: min(100%, 98%); }
      .messages { padding: 10px; }
      .metric-grid { grid-template-columns: repeat(2, 1fr); }
    }
    @keyframes fxPulse { 0%{transform:scale(1)} 40%{transform:scale(1.02)} 100%{transform:scale(1)} }
    @keyframes fxFade { from{opacity:.65} to{opacity:1} }
    @keyframes fxFlicker { 0%,100%{opacity:1} 35%{opacity:.72} 65%{opacity:1} }
  </style>
</head>
<body>
  <main class="app">
    <aside class="panel sidebar">
      <div class="inner">
        <div class="brand">
          <div class="eyebrow">Behaviour-Aware Secure AI Inference</div>
          <h1>Secure Chat</h1>
          <div class="muted">Send prompts through the Zero Trust policy layer and inspect each gateway decision.</div>
        </div>
        <div id="quickLinks" class="row"></div>
        <div class="card"><div class="muted" id="userLine">Checking session...</div></div>
        <label>Model <select id="modelSelect"><option>Login to load models</option></select></label>
        <div id="modelStatus" class="status-card warn">
          <strong>Select a model</strong>
          <small>The gateway will show whether chat is ready, needs setup, or can only run a security pre-screen.</small>
        </div>
        <div class="row">
          <button id="newChatBtn">New Chat</button>
          <button id="deleteChatBtn" class="danger">Delete</button>
        </div>
        <h2>Conversations</h2>
        <div id="sessions" class="sessions"></div>
      </div>
    </aside>

    <section class="panel chat">
      <div class="chat-head">
        <div class="chat-title">
          <strong id="chatTitle">New protected conversation</strong>
          <div id="modelLine" class="muted">Select a model and start chatting.</div>
        </div>
        <div class="row">
          <span id="ztaStatus" class="pill"><span class="dot bad"></span>Login</span>
          <span id="decisionPill" class="pill">No decision</span>
        </div>
      </div>
      <div id="messages" class="messages"></div>
      <div class="composer">
        <textarea id="prompt" placeholder="Ask anything. The gateway will screen your message before sending it to the selected model."></textarea>
        <div class="send-stack">
          <button id="sendBtn">Send</button>
          <button id="stopBtn" class="danger" style="display:none">Stop</button>
          <button id="regenBtn" class="secondary">Regenerate</button>
          <button id="clearBtn" class="secondary">Clear</button>
        </div>
      </div>
    </section>

    <aside class="panel inspector">
      <div class="inner">
        <h2>Gateway Decision</h2>
        <div class="metric-grid">
          <div class="metric"><span class="muted">Trust</span><b id="trustScore">--</b></div>
          <div class="metric"><span class="muted">Penalty</span><b id="penaltyState">--</b></div>
          <div class="metric"><span class="muted">Prompt Risk</span><b id="promptRisk">--</b></div>
          <div class="metric"><span class="muted">Security</span><b id="securityScore">--</b></div>
        </div>
        <div class="card">
          <h2>Quick Starts</h2>
          <div class="quick-grid">
            <button class="quick">Explain this model's safety posture in simple terms.</button>
            <button class="quick">Draft a secure AI usage policy for my team.</button>
            <button class="quick">Help me test this model with a safe red-team checklist.</button>
          </div>
        </div>
        <h2>Explanation Trace</h2>
        <div id="whyBlocked" class="card" style="display:none"></div>
        <div id="decisionTrace" style="display:none"></div>
      </div>
    </aside>
  </main>

  <script>
    const api = "/api/v1";
    const $ = (id) => document.getElementById(id);
    let stateKey = "zta_chat_sessions_v2_anonymous";
    const token = sessionStorage.getItem("zta_token");
    if (!token) location.href = "/login?next=/dashboard/chat";
    const authHeaders = () => ({ Authorization: `Bearer ${token}` });

    let sessions = [];
    let activeId = null;
    let models = [];
    let currentUser = { is_admin: false };
    let abortController = null;
    let streamingActive = false;

    const linkConfig = [
      { label: "Dashboard", href: "/dashboard", requiresAdmin: false },
      { label: "Models", href: "/dashboard/models", requiresAdmin: false },
      { label: "Security Monitor", href: "/dashboard/security-monitor", requiresAdmin: false },
      { label: "Policy Engine", href: "/dashboard/policy", requiresAdmin: false },
      { label: "Research", href: "/dashboard/research", requiresAdmin: true },
    ];

    // ===== Markdown =====
    function setupMarkdown() {
      if (typeof marked === "undefined") return;
      const renderer = {
        code(code, lang) {
          const language = (lang && typeof hljs !== "undefined" && hljs.getLanguage(lang)) ? lang : "plaintext";
          let highlighted;
          try {
            highlighted = (typeof hljs !== "undefined")
              ? hljs.highlight(code, { language }).value
              : escapeHtml(code);
          } catch { highlighted = escapeHtml(code); }
          return `<div class="code-block"><div class="code-header"><span class="code-lang">${escapeHtml(lang || "code")}</span><button class="copy-btn" onclick="copyCode(this)">Copy</button></div><pre><code class="hljs language-${escapeHtml(language)}">${highlighted}</code></pre></div>`;
        }
      };
      marked.use({ renderer, breaks: true, gfm: true });
    }
    setupMarkdown();

    function renderMarkdown(text) {
      if (!text) return "";
      if (typeof marked === "undefined") return `<div style="white-space:pre-wrap">${escapeHtml(text)}</div>`;
      try { return marked.parse(text); } catch { return `<div style="white-space:pre-wrap">${escapeHtml(text)}</div>`; }
    }

    function copyCode(btn) {
      const code = btn.closest(".code-block").querySelector("pre code");
      navigator.clipboard.writeText(code ? code.innerText : "").then(() => {
        const orig = btn.textContent;
        btn.textContent = "Copied!";
        setTimeout(() => { btn.textContent = orig; }, 1500);
      });
    }

    function copyMessage(msgId) {
      const session = activeSession();
      const msg = session.messages.find((m) => m.id === msgId);
      if (msg) navigator.clipboard.writeText(msg.content).catch(() => {});
    }

    // ===== Utilities =====
    function nowTime() {
      return new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    }
    function uid() {
      return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
    }
    function escapeHtml(value) {
      return String(value || "").replace(/[&<>"']/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" }[ch]));
    }
    function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

    // ===== Session State =====
    function save() {
      localStorage.setItem(stateKey, JSON.stringify({ sessions, activeId }));
    }
    function load() {
      try {
        const parsed = JSON.parse(localStorage.getItem(stateKey) || "{}");
        sessions = Array.isArray(parsed.sessions) ? parsed.sessions : [];
        activeId = parsed.activeId || null;
      } catch {
        sessions = [];
        activeId = null;
      }
      if (!sessions.length) createSession(false);
      if (!sessions.some((s) => s.id === activeId)) activeId = sessions[0].id;
    }
    function activeSession() {
      return sessions.find((s) => s.id === activeId);
    }
    function createSession(renderNow = true) {
      const session = { id: uid(), title: "New protected conversation", modelId: null, messages: [], createdAt: Date.now(), updatedAt: Date.now() };
      sessions.unshift(session);
      activeId = session.id;
      save();
      if (renderNow) render();
      return session;
    }

    // ===== API =====
    async function request(path, options = {}) {
      const res = await fetch(path, options);
      const text = await res.text();
      let data;
      try { data = text ? JSON.parse(text) : {}; } catch { data = text; }
      if (!res.ok) {
        const err = new Error(normalizeErrorMessage(data, res.status));
        err.status = res.status;
        err.payload = data;
        throw err;
      }
      return data;
    }
    function normalizeErrorMessage(data, status) {
      const detail = typeof data === "object" ? data.detail : data;
      if (detail && typeof detail === "object" && detail.title) return `${detail.title}: ${detail.explanation || detail.reason || detail.message || ""}`;
      if (detail && typeof detail === "object" && detail.message) return detail.message;
      const raw = typeof detail === "string" ? detail : JSON.stringify(detail || data || "");
      if (raw.includes("HF_TOKEN")) return "This Hugging Face model is not available yet because the server is missing its Hugging Face token.";
      if (status === 503) return "The selected model is temporarily unavailable.";
      if (status === 409) return "This model is not ready for chat yet. Ask an admin to scan or protect it first.";
      if (status === 401 || status === 403) return "Your session is not authorized. Please log in again.";
      return raw || "The gateway could not complete this request.";
    }
    function normalizeErrorDetail(data, status) {
      const detail = typeof data === "object" ? data.detail : data;
      if (detail && typeof detail === "object") return detail;
      return {
        code: status === 401 || status === 403 ? "auth_error" : "gateway_error",
        title: status === 401 || status === 403 ? "Session problem" : "Gateway error",
        reason: normalizeErrorMessage(data, status),
        explanation: normalizeErrorMessage(data, status),
        suggested_fix: status === 401 || status === 403 ? "Log in again from the login page." : "Try again or choose another model.",
        action_required: "user",
      };
    }

    // ===== Decision Panel =====
    function applyDecisionFx(decision) {
      const pill = $("decisionPill");
      pill.classList.remove("fx-block", "fx-allow", "fx-challenge");
      if (decision === "BLOCK") pill.classList.add("fx-block");
      else if (decision === "ALLOW") pill.classList.add("fx-allow");
      else if (decision === "CHALLENGE") pill.classList.add("fx-challenge");
      setTimeout(() => pill.classList.remove("fx-block", "fx-allow", "fx-challenge"), 1200);
    }
    function setDecisionFromStream(data) {
      const decision = String(data.decision || "unknown").toUpperCase();
      $("decisionPill").textContent = decision;
      $("promptRisk").textContent = data.prompt_risk_score == null ? "--" : `${Math.round(data.prompt_risk_score * 100)}%`;
      $("securityScore").textContent = data.security_score == null ? "--" : `${Math.round(data.security_score * 100)}%`;
      applyDecisionFx(decision);
      renderWhy(data);
      showTrace(formatTrace(data));
    }
    function setDecision(data) {
      return setDecisionFromStream(data);
    }
    function renderWhy(data) {
      const panel = $("whyBlocked");
      const factors = data.factors || {};
      const alias = { prompt_risk: "Prompt Risk", user_trust: "User Trust", model_risk: "Model Risk", sensitivity: "Sensitivity" };
      const ordered = ["prompt_risk", "user_trust", "model_risk", "sensitivity"];
      const colorClass = (score) => { const n = Number(score || 0); return n >= 0.7 ? "risky" : n >= 0.4 ? "mid" : "safe"; };
      const factorRows = ordered.filter((k) => factors[k] != null).map((key) => {
        const value = Number(factors[key] || 0);
        const pct = Math.round(value * 100);
        return `<div class="bar"><span>${alias[key]}</span><div class="track"><div class="fill ${colorClass(value)}" style="width:${Math.max(3, Math.min(100, pct))}%"></div></div><b>${pct}%</b></div>`;
      }).join("");
      const extraRows = Object.entries(factors).filter(([k]) => !ordered.includes(k)).map(([key, value]) => {
        const pct = Math.round(Number(value || 0) * 100);
        return `<div class="bar"><span>${escapeHtml(key.replaceAll("_", " "))}</span><div class="track"><div class="fill ${colorClass(value)}" style="width:${Math.max(3, Math.min(100, pct))}%"></div></div><b>${pct}%</b></div>`;
      }).join("");
      const rows = factorRows + extraRows;
      if (!data.explanation && !rows) { panel.style.display = "none"; panel.innerHTML = ""; return; }
      const decision = String(data.decision || "").toUpperCase() || "UNKNOWN";
      const pr = Number(factors.prompt_risk || data.prompt_risk_score || 0);
      const ut = Number(factors.user_trust || 0);
      const mr = Number(factors.model_risk || 0);
      const flow = `Prompt Risk ${Math.round(pr * 100)}% → User Trust ${Math.round(ut * 100)}% → Model Risk ${Math.round(mr * 100)}% → ${decision}`;
      panel.style.display = "grid";
      panel.innerHTML = `
        <h2>${String(data.decision || "").toLowerCase() === "block" ? "Why blocked?" : "Why this decision?"}</h2>
        <div class="muted">${escapeHtml(data.explanation || data.reason || "Gateway decision completed.")}</div>
        <div class="mini-bars">${rows}</div>
        <div class="flow">${escapeHtml(flow)}</div>
        <button id="traceToggleBtn" class="secondary trace-toggle">Show Decision Trace</button>
        <div id="traceDetails" class="trace-collapsible"><pre>${escapeHtml(JSON.stringify(data.decision_trace || {}, null, 2))}</pre></div>
      `;
      const btn = $("traceToggleBtn");
      const details = $("traceDetails");
      if (btn && details) {
        btn.onclick = () => {
          const open = details.classList.toggle("open");
          btn.textContent = open ? "Hide Decision Trace" : "Show Decision Trace";
        };
      }
    }
    function setStructuredTrace(detail, status) {
      const policyText = detail.policy_decision ? String(detail.policy_decision).toUpperCase() : "";
      $("decisionPill").textContent = detail.status === "model_not_callable" && policyText ? `Pre-screen ${policyText}` : (policyText || "Unavailable");
      $("promptRisk").textContent = detail.prompt_risk_score == null ? "--" : `${Math.round(detail.prompt_risk_score * 100)}%`;
      $("securityScore").textContent = detail.security_score == null ? "--" : `${Math.round(detail.security_score * 100)}%`;
      showTrace({ status: detail.status || "gateway_notice", code: detail.code, title: detail.title, reason: detail.reason, explanation: detail.explanation, suggested_fix: detail.suggested_fix, action_required: detail.action_required || "user" });
    }
    function setUnavailableTrace(message, status) {
      $("decisionPill").textContent = "Unavailable";
      $("promptRisk").textContent = "--";
      $("securityScore").textContent = "--";
      showTrace({ status: "model_unavailable", http_status: status || null, user_message: message });
    }
    function formatTrace(data) {
      return {
        decision: data.decision,
        blocked: data.blocked,
        prompt_risk: data.prompt_risk_score == null ? null : `${Math.round(data.prompt_risk_score * 100)}%`,
        security_score: data.security_score == null ? null : `${Math.round(data.security_score * 100)}%`,
        explanation: data.explanation,
        factors: data.factors || {},
        secure_mode: data.secure_mode_enabled ? "on" : "off",
        summary: data.reason || "Gateway decision completed.",
      };
    }
    function showTrace(value) {
      $("decisionTrace").textContent = typeof value === "string" ? value : JSON.stringify(value, null, 2);
      $("decisionTrace").style.display = "block";
    }

    // ===== Inline decision badge =====
    function decisionBadgeHTML(gatewayData) {
      if (!gatewayData) return "";
      const d = String(gatewayData.decision || "").toUpperCase();
      const pr = Math.round((gatewayData.prompt_risk_score || 0) * 100);
      const sc = Math.round((gatewayData.security_score || 0) * 100);
      const cls = d === "BLOCK" ? "badge-block" : d === "CHALLENGE" ? "badge-challenge" : "badge-allow";
      const title = escapeHtml(gatewayData.reason || "");
      return `<div class="decision-badge ${cls}" title="${title}">${escapeHtml(d)} · Risk ${pr}% · Security ${sc}%</div>`;
    }

    // ===== Message Rendering =====
    function renderMessageBubble(msg) {
      const id = msg.id || "";
      if (msg.role === "user") {
        return `
          <article class="bubble user" data-id="${id}">
            <div class="bubble-head">
              <span>YOU</span>
              <div class="bubble-actions">
                <button class="action-btn" onclick="editMessage('${id}')">Edit</button>
                <span>${msg.time || ""}</span>
              </div>
            </div>
            <div class="bubble-content">${escapeHtml(msg.content || "")}</div>
          </article>`;
      }
      if (msg.role === "assistant") {
        const badge = decisionBadgeHTML(msg.gateway);
        const content = msg.streaming
          ? `${escapeHtml(msg.content || "")}<span class="stream-cursor"></span>`
          : `<div class="markdown-body">${renderMarkdown(msg.content || "")}</div>`;
        return `
          <article class="bubble assistant" data-id="${id}">
            <div class="bubble-head">
              <span>AI</span>
              <div class="bubble-actions">
                <button class="action-btn" onclick="copyMessage('${id}')">Copy</button>
                <span>${msg.time || ""}</span>
              </div>
            </div>
            <div class="bubble-content">${content}</div>
            ${msg.streaming ? `<div class="decision-badge badge-pending">Evaluating...</div>` : badge}
          </article>`;
      }
      return `
        <article class="bubble system" data-id="${id}">
          <div class="bubble-head"><span>GATEWAY</span><span>${msg.time || ""}</span></div>
          <div class="bubble-content">${escapeHtml(msg.content || "")}</div>
        </article>`;
    }

    function renderSessions() {
      $("sessions").innerHTML = sessions.map((session) => {
        const count = session.messages.filter((m) => m.role !== "system").length;
        return `<button class="session ${session.id === activeId ? "active" : ""}" data-id="${session.id}">${escapeHtml(session.title)}<small>${count} messages</small></button>`;
      }).join("");
      document.querySelectorAll(".session").forEach((btn) => {
        btn.addEventListener("click", () => { activeId = btn.dataset.id; save(); render(); });
      });
    }

    function renderMessages() {
      const session = activeSession();
      $("chatTitle").textContent = session.title;
      const selected = models.find((m) => String(m.id) === String(session.modelId || $("modelSelect").value));
      const runtime = selected?.runtime;
      const runtimeLabel = runtime?.label || (runtime?.runtime_ready === false ? "Needs setup" : "Ready");
      $("modelLine").textContent = selected ? `${selected.name} · ${selected.model_type} · ${runtimeLabel}` : "Select a model and start chatting.";
      renderSelectedModelStatus(selected);
      if (session.modelId && $("modelSelect").value !== String(session.modelId)) $("modelSelect").value = String(session.modelId);

      if (!session.messages.length) {
        const readyCount = models.filter((m) => m.runtime?.runtime_ready !== false).length;
        const hasAny = models.length > 0;
        $("messages").innerHTML = `<div class="empty">
          <strong>${hasAny ? "Start A Protected Chat" : "No Models Available Yet"}</strong>
          <span>${hasAny ? "Choose a registered model, ask normally, and the gateway will keep the conversation screened with prompt guard, formal risk, trust scoring, and audit logging." : "No chat-capable models are currently visible to your account."}</span>
          ${hasAny ? `<span class="muted">Runtime-ready models: ${readyCount}</span>` : ""}
        </div>`;
        return;
      }
      $("messages").innerHTML = session.messages.map(renderMessageBubble).join("");
      $("messages").scrollTop = $("messages").scrollHeight;
    }

    function render() {
      renderSessions();
      renderMessages();
      save();
    }

    // ===== Streaming Send =====
    function setStreamingMode(active) {
      streamingActive = active;
      $("sendBtn").style.display = active ? "none" : "";
      $("stopBtn").style.display = active ? "" : "none";
      $("regenBtn").disabled = active;
    }

    function updateBubbleInPlace(msgId, content, isStreaming) {
      const el = document.querySelector(`[data-id="${msgId}"] .bubble-content`);
      if (!el) return;
      if (isStreaming) {
        el.innerHTML = escapeHtml(content || "") + '<span class="stream-cursor"></span>';
      } else {
        el.innerHTML = `<div class="markdown-body">${renderMarkdown(content || "")}</div>`;
      }
      $("messages").scrollTop = $("messages").scrollHeight;
    }

    function updateBadgeInPlace(msgId, gatewayData) {
      const article = document.querySelector(`[data-id="${msgId}"]`);
      if (!article) return;
      const existing = article.querySelector(".decision-badge");
      if (existing) existing.outerHTML = decisionBadgeHTML(gatewayData);
    }

    function animateContent(msgId, fullText, onDone) {
      const words = (fullText || "").split(/(\s+)/);
      const STEPS = Math.min(words.length, 50);
      const chunkSize = Math.max(1, Math.ceil(words.length / STEPS));
      let step = 0;
      const interval = setInterval(() => {
        step++;
        const shown = words.slice(0, step * chunkSize).join("");
        const finished = step * chunkSize >= words.length;
        if (finished) {
          clearInterval(interval);
          updateBubbleInPlace(msgId, fullText, false);
          if (onDone) onDone();
        } else {
          const el = document.querySelector(`[data-id="${msgId}"] .bubble-content`);
          if (el) {
            el.innerHTML = `<div class="markdown-body">${renderMarkdown(shown + " ▊")}</div>`;
            $("messages").scrollTop = $("messages").scrollHeight;
          }
        }
      }, 25);
    }

    async function sendMessage(promptOverride) {
      const session = activeSession();
      const raw = (promptOverride !== undefined ? promptOverride : $("prompt").value).trim();
      if (!raw) return;

      const modelId = Number($("modelSelect").value || session.modelId);
      if (!modelId) { showTrace("Select a model first."); return; }

      session.modelId = modelId;
      if (session.title === "New protected conversation") session.title = raw.slice(0, 54) || session.title;

      // Build real multi-turn messages array
      const history = session.messages
        .filter((m) => m.role === "user" || m.role === "assistant")
        .map((m) => ({ role: m.role, content: m.content }));
      const messages = [...history, { role: "user", content: raw }];

      const userMsgId = uid();
      session.messages.push({ id: userMsgId, role: "user", content: raw, time: nowTime() });

      const asstMsgId = uid();
      session.messages.push({ id: asstMsgId, role: "assistant", content: "", streaming: true, time: nowTime() });

      if (promptOverride === undefined) $("prompt").value = "";
      render();
      setStreamingMode(true);

      abortController = new AbortController();
      let gatewayData = null;
      let fullContent = "";

      try {
        const response = await fetch(`${api}/usage/stream-infer`, {
          method: "POST",
          headers: { ...authHeaders(), "Content-Type": "application/json" },
          body: JSON.stringify({ model_id: modelId, prompt: raw, messages, parameters: { temperature: 0.7, max_tokens: 700 } }),
          signal: abortController.signal,
        });

        if (!response.ok) {
          const errData = await response.json().catch(() => ({}));
          throw Object.assign(new Error(), { status: response.status, payload: errData });
        }

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";
        let streamDone = false;

        while (!streamDone) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const parts = buffer.split("\\n\\n");
          buffer = parts.pop() ?? "";

          for (const part of parts) {
            if (!part.startsWith("data: ")) continue;
            let evt;
            try { evt = JSON.parse(part.slice(6)); } catch { continue; }

            if (evt.type === "decision") {
              gatewayData = evt;
              setDecisionFromStream(evt);
              updateBadgeInPlace(asstMsgId, evt);

            } else if (evt.type === "content") {
              fullContent = evt.text || "";
              if (evt.blocked || !fullContent) {
                // Output was blocked — finalise immediately
                const msg = session.messages.find((m) => m.id === asstMsgId);
                if (msg) {
                  msg.content = gatewayData?.reason || "Request blocked by gateway.";
                  msg.role = "system";
                  msg.streaming = false;
                  msg.gateway = gatewayData;
                }
                render();
              } else {
                animateContent(asstMsgId, fullContent, null);
              }

            } else if (evt.type === "error") {
              const msg = session.messages.find((m) => m.id === asstMsgId);
              if (msg) {
                msg.content = evt.message || "An error occurred.";
                msg.role = "system";
                msg.streaming = false;
              }
              render();
              streamDone = true;
              break;

            } else if (evt.type === "done") {
              const isBlocked = evt.blocked || (gatewayData && gatewayData.blocked);
              if (!isBlocked && fullContent) {
                // Animation may still be running — finalize when it completes
                const msg = session.messages.find((m) => m.id === asstMsgId);
                if (msg) { msg.content = fullContent; msg.streaming = false; msg.gateway = gatewayData; }
              } else if (!fullContent) {
                const msg = session.messages.find((m) => m.id === asstMsgId);
                if (msg && msg.streaming) {
                  msg.content = isBlocked ? (gatewayData?.reason || "Blocked by gateway.") : "No output returned.";
                  msg.role = isBlocked ? "system" : "assistant";
                  msg.streaming = false;
                  msg.gateway = gatewayData;
                }
                render();
              }
              session.updatedAt = Date.now();
              save();
              await loadProfile();
              streamDone = true;
            }
          }
        }
      } catch (err) {
        if (err.name === "AbortError") {
          const msg = session.messages.find((m) => m.id === asstMsgId);
          if (msg) { msg.content = "[Stopped by user]"; msg.role = "system"; msg.streaming = false; }
          render();
        } else {
          const detail = normalizeErrorDetail(err.payload || err.message, err.status);
          setStructuredTrace(detail, err.status);
          renderGatewayNotice(detail, "bad");
          const msg = session.messages.find((m) => m.id === asstMsgId);
          if (msg) {
            msg.content = `${detail.title || "Gateway notice"}\\n${detail.explanation || detail.reason || ""}\\nNext: ${detail.suggested_fix || "Try another model or ask an admin."}`;
            msg.role = "system";
            msg.streaming = false;
          }
          render();
        }
      } finally {
        setStreamingMode(false);
        abortController = null;
        // Ensure the message is finalised even if something went wrong above
        const msg = session.messages.find((m) => m.id === asstMsgId);
        if (msg && msg.streaming) { msg.streaming = false; render(); }
      }
    }

    function stopStreaming() {
      if (abortController) abortController.abort();
    }

    function regenerate() {
      if (streamingActive) return;
      const session = activeSession();
      const msgs = session.messages;
      // Remove trailing non-user messages
      while (msgs.length && msgs[msgs.length - 1].role !== "user") msgs.pop();
      if (!msgs.length) return;
      const lastUser = msgs[msgs.length - 1];
      msgs.pop();
      save();
      render();
      sendMessage(lastUser.content);
    }

    function editMessage(msgId) {
      if (streamingActive) return;
      const session = activeSession();
      const idx = session.messages.findIndex((m) => m.id === msgId);
      if (idx < 0) return;
      const content = session.messages[idx].content;
      session.messages.splice(idx);
      save();
      render();
      $("prompt").value = content;
      $("prompt").focus();
    }

    function deleteChat() {
      if (sessions.length <= 1) { sessions = []; createSession(false); } else { sessions = sessions.filter((s) => s.id !== activeId); activeId = sessions[0].id; }
      render();
    }
    function clearCurrent() {
      const session = activeSession();
      session.messages = [];
      session.title = "New protected conversation";
      session.updatedAt = Date.now();
      render();
    }

    // ===== UI helpers =====
    function renderSelectedModelStatus(selected) {
      if (!selected) {
        $("modelStatus").className = "status-card warn";
        $("modelStatus").innerHTML = `<strong>No model selected</strong><small>Choose a registered model to see whether it can chat now.</small>`;
        $("sendBtn").textContent = "Send";
        $("sendBtn").disabled = true;
        return;
      }
      const runtime = selected.runtime || {};
      const ready = runtime.runtime_ready !== false;
      const canPrescreen = runtime.can_prescreen !== false;
      const severity = ready ? "ready" : (canPrescreen ? "warn" : "bad");
      $("modelStatus").className = `status-card ${severity}`;
      $("modelStatus").innerHTML = `
        <strong>${escapeHtml(runtime.label || (ready ? "Ready" : "Needs setup"))}</strong>
        <small>${escapeHtml(runtime.explanation || runtime.message || "Runtime status is not available.")}</small>
        <small><b>Next:</b> ${escapeHtml(runtime.suggested_fix || runtime.next_step || "Choose a ready model or ask an admin to check setup.")}</small>
      `;
      $("sendBtn").textContent = ready ? "Send" : (canPrescreen ? "Pre-screen" : "Unavailable");
      $("sendBtn").disabled = !canPrescreen;
    }

    function renderQuickLinks() {
      const visible = linkConfig.filter((item) => currentUser.is_admin || !item.requiresAdmin);
      $("quickLinks").innerHTML = visible.map((item) =>
        `<a class="secondary" href="${item.href}">${escapeHtml(item.label)}${item.requiresAdmin ? ' <span class="badge">Admin</span>' : ""}</a>`
      ).join("") + `<button id="logoutBtn" class="secondary">Logout</button>`;
      $("logoutBtn").addEventListener("click", () => { sessionStorage.removeItem("zta_token"); location.href = "/login"; });
    }

    function renderGatewayNotice(detail, severity = "warn") {
      const panel = $("whyBlocked");
      panel.style.display = "grid";
      panel.innerHTML = `
        <h2>${escapeHtml(detail.title || "Gateway notice")}</h2>
        <div class="muted">${escapeHtml(detail.explanation || detail.reason || "The gateway returned a status update.")}</div>
        <div class="flow"><b>Next:</b> ${escapeHtml(detail.suggested_fix || "Choose another model or ask an admin.")}</div>
      `;
      panel.className = severity === "bad" ? "card status-card bad" : "card";
    }

    // ===== Auth / Data Loading =====
    async function afterAuth() {
      await Promise.all([loadProfile(), loadModels(), zta()]);
    }
    async function loadProfile() {
      const data = await request(`${api}/auth/me/profile`, { headers: authHeaders() });
      currentUser = { is_admin: Boolean((data.user?.scopes || []).includes("admin")) };
      const username = data.user?.username;
      if (username) {
        const userKey = "zta_chat_sessions_v2_" + username.toLowerCase().replace(/[^a-z0-9_-]/g, "_");
        if (stateKey !== userKey) { stateKey = userKey; load(); render(); }
      }
      $("userLine").textContent = `${username || "User"} · trust ${data.trust?.trust_score ?? "--"} · ${data.security_posture?.status || "active"}`;
      $("trustScore").textContent = data.trust?.trust_score ?? "--";
      $("penaltyState").textContent = data.rate?.penalty_active ? `${data.rate.cooldown_remaining_seconds}s` : "Clear";
      renderQuickLinks();
    }
    async function loadModels() {
      const [modelRows, readinessRows] = await Promise.all([
        request(`${api}/models/`, { headers: authHeaders() }),
        request(`${api}/models/runtime-readiness`, { headers: authHeaders() })
      ]);
      const runtimeById = new Map((readinessRows || []).map((item) => [String(item.model_id), item]));
      models = modelRows.map((m) => ({ ...m, runtime: runtimeById.get(String(m.id)) || null }));
      $("modelSelect").innerHTML = models.map((m) => {
        const label = m.runtime?.label || (m.runtime?.runtime_ready === false ? "Needs setup" : "Ready");
        return `<option value="${m.id}">${escapeHtml(m.name)} · ${escapeHtml(label)}</option>`;
      }).join("") || `<option value="">No models registered</option>`;
      const session = activeSession();
      const selected = models.find((m) => String(m.id) === String(session.modelId));
      const readyModel = models.find((m) => m.runtime?.runtime_ready !== false);
      if ((!session.modelId || selected?.runtime?.runtime_ready === false) && readyModel) session.modelId = readyModel.id;
      if (!session.modelId && models[0]) session.modelId = models[0].id;
      if (session.modelId) $("modelSelect").value = String(session.modelId);
      if (!readyModel) {
        setStructuredTrace({ code: "no_ready_models", title: "No ready models", reason: "Every registered model needs setup.", explanation: "You can select a model and run the gateway pre-screen, but inference will not run until an admin fixes model setup.", suggested_fix: "Ask an admin to configure provider tokens or enable a protected model.", action_required: "admin", status: "model_not_callable" }, 503);
        renderGatewayNotice({ title: "No Ready Models", explanation: "Models are registered, but none are ready for full inference yet.", suggested_fix: "Ask an admin to configure runtime credentials." });
      }
      if (!models.length) {
        $("modelStatus").className = "status-card bad";
        $("modelStatus").innerHTML = `<strong>No models available</strong><small>Your account currently has no visible models for chat.</small><small><b>Next:</b> Ask an admin to onboard and activate a model.</small>`;
        $("sendBtn").textContent = "Unavailable";
        $("sendBtn").disabled = true;
      }
      render();
    }
    async function zta() {
      try {
        const data = await request(`${api}/monitoring/zta/status`, { headers: authHeaders() });
        $("ztaStatus").innerHTML = `<span class="dot ${data.enabled ? "" : "bad"}"></span>${data.enabled ? "Protected" : "Unprotected"}`;
      } catch {
        $("ztaStatus").innerHTML = `<span class="dot bad"></span>Login`;
      }
    }

    // ===== Event Wiring =====
    $("sendBtn").addEventListener("click", () => sendMessage());
    $("stopBtn").addEventListener("click", stopStreaming);
    $("regenBtn").addEventListener("click", regenerate);
    $("newChatBtn").addEventListener("click", () => createSession(true));
    $("deleteChatBtn").addEventListener("click", deleteChat);
    $("clearBtn").addEventListener("click", clearCurrent);
    $("modelSelect").addEventListener("change", () => {
      const session = activeSession();
      session.modelId = Number($("modelSelect").value);
      render();
    });
    $("prompt").addEventListener("keydown", (event) => {
      if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); sendMessage(); }
    });
    document.querySelectorAll(".quick").forEach((button) => {
      button.addEventListener("click", () => { $("prompt").value = button.textContent.trim(); $("prompt").focus(); });
    });

    load();
    render();
    afterAuth().catch(() => { sessionStorage.removeItem("zta_token"); location.href = "/login?next=/dashboard/chat"; });
    zta();
  </script>
</body>
</html>
""".replace("</style>", f"{CYBER_UI_CSS}\n  </style>").replace("</body>", f"{CYBER_UI_JS}\n</body>")
