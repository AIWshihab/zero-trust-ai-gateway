from app.ui.common import CYBER_UI_CSS, CYBER_UI_JS


RESEARCH_HTML = """
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Replayable Security Evaluation</title>
  <style>
    :root {
      color-scheme: dark;
      --text: #fff7ea;
      --muted: #d4c0a4;
      --soft: #aab3bf;
      --amber: #ffb13b;
      --green: #78e08f;
      --red: #ff4d3d;
      --ink: #080604;
      font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      min-height: 100vh;
      color: var(--text);
      background:
        linear-gradient(118deg, rgba(255,255,255,.035) 0 1px, transparent 1px 70px),
        radial-gradient(circle at 18% 10%, rgba(255,159,28,.25), transparent 30%),
        linear-gradient(140deg, #070706 0%, #15110d 45%, #2b1207 82%, #070706 100%);
    }
    .shell { padding: 20px clamp(14px, 3vw, 34px) 34px; }
    header { display: grid; grid-template-columns: minmax(280px, 1fr) auto; gap: 16px; align-items: start; margin-bottom: 16px; }
    .eyebrow { color: var(--amber); text-transform: uppercase; letter-spacing: .12em; font-weight: 950; font-size: 12px; }
    h1 { margin: 6px 0 10px; font-size: clamp(34px, 5vw, 62px); line-height: .92; text-transform: uppercase; text-shadow: 4px 4px 0 #000, 8px 8px 0 rgba(244,123,32,.34); }
    p { color: #ffe9c5; line-height: 1.55; font-weight: 720; max-width: 900px; }
    a, button {
      border: 2px solid var(--ink);
      border-radius: 7px;
      padding: 10px 12px;
      color: #150905;
      background: linear-gradient(135deg, #ffd164, #ff7a1a 52%, #f0441f);
      font-weight: 900;
      cursor: pointer;
      text-decoration: none;
      box-shadow: 4px 4px 0 rgba(0,0,0,.75);
      font: inherit;
    }
    a.secondary, button.secondary { color: var(--text); background: rgba(255,241,213,.08); border-color: rgba(255,178,77,.42); }
    .row { display: flex; flex-wrap: wrap; gap: 10px; align-items: center; }
    .grid { display: grid; grid-template-columns: repeat(4, minmax(150px, 1fr)); gap: 12px; margin-bottom: 14px; }
    .wide { display: grid; grid-template-columns: 1.1fr .9fr; gap: 14px; }
    .card {
      border: 2px solid var(--ink);
      border-radius: 7px;
      background: rgba(18,18,16,.94);
      box-shadow: 6px 6px 0 rgba(0,0,0,.72), 0 22px 70px rgba(0,0,0,.34);
      position: relative;
      overflow: hidden;
    }
    .card::after { content: ""; position: absolute; inset: 0; pointer-events: none; background: repeating-linear-gradient(-12deg, transparent 0 19px, rgba(255,159,28,.05) 20px 22px); }
    .inner { position: relative; z-index: 1; padding: 14px; }
    .label { color: var(--muted); font-size: 12px; text-transform: uppercase; letter-spacing: .08em; font-weight: 900; }
    .value { margin-top: 7px; font-size: 27px; font-weight: 950; }
    h2 { margin: 0 0 8px; color: var(--amber); text-transform: uppercase; letter-spacing: .08em; font-size: 16px; }
    ul { margin: 8px 0 0; padding-left: 18px; color: var(--soft); line-height: 1.5; }
    .evidence-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; }
    .evidence-list { display: grid; gap: 8px; margin-top: 10px; }
    .evidence-row { display: flex; justify-content: space-between; gap: 12px; border-top: 1px solid rgba(255,255,255,.08); padding-top: 8px; color: var(--soft); font-size: 13px; }
    .evidence-row b { color: var(--text); font-variant-numeric: tabular-nums; }
    .badge { display: inline-flex; align-items: center; border: 1px solid rgba(255,255,255,.14); border-radius: 999px; padding: 4px 8px; font-size: 11px; color: var(--soft); background: rgba(255,255,255,.04); }
    .badge.good { color: var(--green); border-color: rgba(120,224,143,.35); }
    .badge.warn { color: var(--amber); border-color: rgba(255,177,59,.35); }
    .empty-state { display:none; margin-bottom:14px; border: 1px dashed rgba(255,255,255,.18); border-radius: 10px; padding: 16px; color: var(--soft); background: rgba(255,255,255,.035); }
    .table-wrap { overflow-x: auto; }
    table { width: 100%; border-collapse: collapse; font-size: 13px; color: var(--soft); }
    th, td { text-align: left; padding: 9px 8px; border-bottom: 1px solid rgba(255,255,255,.08); vertical-align: top; }
    th { color: #93c5fd; font-size: 11px; text-transform: uppercase; letter-spacing: .06em; }
    .summary-copy { color: var(--soft); line-height: 1.55; margin: 8px 0 0; font-size: 13px; }
    details.advanced { margin-top: 14px; }
    details.advanced summary { cursor: pointer; color: #93c5fd; font-weight: 800; margin-bottom: 10px; }
    details.advanced[hidden] { display: none; }
    pre {
      white-space: pre-wrap;
      word-break: break-word;
      border: 2px solid rgba(255,178,77,.24);
      border-radius: 8px;
      padding: 12px;
      background: rgba(8,6,4,.82);
      color: #fff1d5;
      max-height: 430px;
      overflow: auto;
    }
    .good { color: var(--green); }
    .bad { color: var(--red); }
    @media (max-width: 1050px) { .grid, .wide { grid-template-columns: repeat(2, 1fr); } }
    @media (max-width: 760px) {
      header, .grid, .wide, .evidence-grid { grid-template-columns: 1fr; }
      .row { flex-wrap: wrap; gap: 6px; }
    }
    @media (max-width: 420px) {
      h1 { font-size: clamp(26px, 8vw, 48px); }
      .shell { padding: 12px; }
    }
  </style>
</head>
<body>
  <main class="shell">
    <header>
      <div>
        <div class="eyebrow">Research-Grade Evaluation</div>
        <h1>Replayable Security Evaluation</h1>
        <p>This system produces replayable, explainable security evidence: policy replay, counterfactuals, model comparison, and control effectiveness derived from audit decisions.</p>
      </div>
      <div class="row">
        <a class="secondary" href="/dashboard">Dashboard</a>
        <a class="secondary" href="/dashboard/security-monitor">Security Monitor</a>
        <button id="reloadBtn">Refresh</button>
      </div>
    </header>
    <div class="tabs row mb-4">
      <button class="tab active" data-tab="test-suite">Test Suite</button>
      <button class="tab" data-tab="policy-replay">Policy Replay</button>
      <button class="tab" data-tab="counterfactuals">Counterfactuals</button>
      <button class="tab" data-tab="model-comparison">Model Comparison</button>
      <button class="tab" data-tab="control-effectiveness">Control Effectiveness</button>
    </div>
    <section class="grid">
      <div class="card"><div class="inner"><div class="label">Attack Block Rate</div><div id="blockRate" class="value">--</div></div></div>
      <div class="card"><div class="inner"><div class="label">False Positive Rate</div><div id="falsePositiveRate" class="value">--</div></div></div>
      <div class="card"><div class="inner"><div class="label">Allow / Challenge / Block</div><div id="distribution" class="value">--</div></div></div>
      <div class="card"><div class="inner"><div class="label">Replay Evidence</div><div id="requests" class="value">--</div></div></div>
    </section>
    <section id="emptyState" class="empty-state">No evaluation evidence yet. Run secure inference or execute a test suite to generate replayable security data.</section>
    <section class="wide tab-panel" data-panel="test-suite">
      <article class="card"><div class="inner"><h2>Research Findings</h2><ul id="findings"><li>Loading...</li></ul></div></article>
      <article class="card"><div class="inner"><h2>Test Summary</h2><div id="testSummary" class="evidence-list"></div></div></article>
    </section>
    <section class="wide tab-panel mt-4" data-panel="policy-replay">
      <article class="card"><div class="inner"><h2>Policy Replay</h2><div id="replay" class="table-wrap"></div></div></article>
      <article class="card"><div class="inner"><h2>Dataset Export</h2><div id="dataset" class="evidence-list"></div></div></article>
    </section>
    <section class="wide tab-panel mt-4 hidden" data-panel="counterfactuals">
      <article class="card"><div class="inner"><h2>Counterfactuals</h2><div id="counterfactualDetails" class="table-wrap"></div></div></article>
      <article class="card"><div class="inner"><h2>Replay Result</h2><div id="replayResult" class="evidence-list"></div></div></article>
    </section>
    <section class="wide tab-panel mt-4 hidden" data-panel="model-comparison">
      <article class="card"><div class="inner"><h2>Model Comparison</h2><p class="summary-copy" id="modelComparison">Compare owned models from Secure Chat or the model comparison API. Results are logged as replayable evidence.</p></div></article>
      <article class="card"><div class="inner"><h2>Cross-Model Escalation Detection</h2><div id="crossModel" class="evidence-list"></div></div></article>
    </section>
    <section class="wide tab-panel mt-4 hidden" data-panel="control-effectiveness">
      <article class="card"><div class="inner"><h2>Control Contribution</h2><ul id="controls"><li>Loading...</li></ul></div></article>
      <article class="card"><div class="inner"><h2>Effectiveness Summary</h2><div id="effectiveness" class="evidence-list"></div></div></article>
    </section>
    <section class="card mt-4">
      <div class="inner">
        <h2>Research Evidence Summary</h2>
        <div class="evidence-grid">
          <div>
            <div class="label">Contribution</div>
            <p class="summary-copy">Behaviour-aware Zero Trust policy enforcement for secure AI model serving.</p>
          </div>
          <div>
            <div class="label">Privacy</div>
            <div id="privacySummary" class="evidence-list"></div>
          </div>
        </div>
        <div class="mt-3">
          <div class="label">Recommended Next Steps</div>
          <ul id="nextSteps"></ul>
        </div>
      </div>
    </section>
    <section id="status" class="empty-state">Loading research evaluation...</section>
  </main>
  <script>
    const api = "/api/v1";
    const token = sessionStorage.getItem("zta_token");
    const $ = (id) => document.getElementById(id);
    if (!token) location.href = "/login?next=/research";
    const authHeaders = () => ({ Authorization: `Bearer ${token}` });
    async function request(path) {
      const res = await fetch(path, { headers: authHeaders() });
      const text = await res.text();
      let data;
      try { data = text ? JSON.parse(text) : {}; } catch { data = text; }
      if (!res.ok) {
        if (res.status === 401) location.href = "/dashboard";
        const detail = typeof data === "object" ? data.detail : data;
        const message = typeof detail === "object" ? (detail.message || detail.title || "Request failed.") : (detail || "Request failed.");
        throw new Error(message);
      }
      return data;
    }
    function pct(value) {
      const n = Number(value || 0);
      return `${Math.round(n * 100)}%`;
    }
    function escHtml(s) {
      return String(s ?? "").replace(/[&<>"']/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[c]);
    }
    function evidenceRows(rows) {
      return rows.map(([label, value]) => `<div class="evidence-row"><span>${escHtml(label)}</span><b>${escHtml(value)}</b></div>`).join("");
    }
    function yesNo(value) {
      return value ? "Yes" : "No";
    }
    function renderReplayTable(modes = []) {
      if (!modes.length) return `<div class="summary-copy">No replay modes are available yet.</div>`;
      return `<table><thead><tr><th>Mode</th><th>Total</th><th>Allowed</th><th>Challenged</th><th>Blocked</th><th>Block Rate</th><th>Changed</th></tr></thead><tbody>
        ${modes.map((mode) => `<tr>
          <td><span class="badge">${escHtml(mode.mode)}</span></td>
          <td>${mode.total_requests || 0}</td>
          <td>${mode.allowed || 0}</td>
          <td>${mode.challenged || 0}</td>
          <td>${mode.blocked || 0}</td>
          <td>${pct(mode.block_rate)}</td>
          <td>${mode.difference_vs_original?.changed_decisions || 0}</td>
        </tr>`).join("")}
      </tbody></table>`;
    }
    function renderCounterfactualTable(summary = {}) {
      const counts = summary.difference_counts || {};
      const entries = Object.entries(counts);
      if (!entries.length) return `<div class="summary-copy">No counterfactual decision differences have been observed yet.</div>`;
      return `<table><thead><tr><th>Removed Layer</th><th>Changed Decisions</th><th>Interpretation</th></tr></thead><tbody>
        ${entries.map(([name, count]) => `<tr><td>${escHtml(name.replaceAll("_", " "))}</td><td>${count}</td><td>Decision changed when this adaptive layer was removed.</td></tr>`).join("")}
      </tbody></table>`;
    }
    function renderList(id, rows, mapper) {
      $(id).innerHTML = rows.length ? rows.map((row) => `<li>${mapper(row)}</li>`).join("") : "<li>No evidence yet.</li>";
    }
    function setTab(tabId) {
      document.querySelectorAll(".tab").forEach((tab) => tab.classList.toggle("active", tab.dataset.tab === tabId));
      document.querySelectorAll(".tab-panel").forEach((panel) => {
        const active = panel.dataset.panel === tabId;
        panel.classList.toggle("hidden", !active);
        panel.style.display = active ? "" : "none";
      });
    }
    async function load() {
      $("status").textContent = "Loading research evaluation...";
      $("status").style.display = "block";
      const [report, replay, dataset] = await Promise.all([
        request(`${api}/research/evaluation-report`),
        request(`${api}/research/policy-replay`),
        request(`${api}/research/evaluation-dataset?limit=50`).catch((err) => ({
          row_count: 0,
          raw_prompt_text_included: false,
          columns: [],
          admin_only: true,
          message: err.message || "Dataset export is admin-only."
        }))
      ]);
      const sample = report.sample || {};
      const decisionCounts = sample.decision_counts || {};
      const requestCount = Number(sample.request_logs || 0);
      $("requests").textContent = requestCount;
      $("blockRate").textContent = pct(report.sample.block_rate);
      $("falsePositiveRate").textContent = pct(report.sample.false_positive_rate || 0);
      $("distribution").textContent = `${decisionCounts.allow || 0}/${decisionCounts.challenge || 0}/${decisionCounts.block || 0}`;
      $("emptyState").style.display = requestCount ? "none" : "block";
      renderList("findings", report.findings || [], (item) => item);
      renderList("controls", report.control_effectiveness_summary.top_controls || [], (item) => `${item.control_id} · ${item.control_name} · ${Math.round((item.contribution_percentage || 0) * 100)}%`);
      $("testSummary").innerHTML = evidenceRows([
        ["Sample Size", requestCount],
        ["Attack Block Rate", pct(sample.block_rate)],
        ["False Positive Rate", pct(sample.false_positive_rate || 0)],
        ["Research Readiness", pct(report.research_readiness?.score || 0)],
        ["Last Evaluation Run", new Date().toLocaleString()]
      ]);
      $("replay").innerHTML = renderReplayTable(replay.modes || []);
      $("counterfactualDetails").innerHTML = renderCounterfactualTable(report.counterfactual_summary || {});
      $("replayResult").innerHTML = evidenceRows([
        ["Replay Source", replay.source || "request_logs.decision_trace"],
        ["Inference Re-run", yesNo(Boolean(replay.inference_rerun))],
        ["Replay Modes", (replay.modes || []).map((mode) => mode.mode).join(", ") || "None"],
        ["Formal Risk Evaluation", replay.formal_risk_evaluation ? "Available" : "No evidence yet"]
      ]);
      const threat = report.threat_intelligence_metrics || {};
      $("crossModel").innerHTML = evidenceRows([
        ["Scope", report.scope === "global" ? "Global" : "Current user"],
        ["Cross-model abuse detections", threat.cross_model_abuse_detections ?? "Admin-only or no evidence"],
        ["Attack sequence count", threat.attack_sequence_count ?? sample.attack_sequence_events ?? 0],
        ["Average sequence severity", threat.average_sequence_severity ?? "No evidence yet"]
      ]);
      $("effectiveness").innerHTML = evidenceRows([
        ["Enforcement decisions", report.control_effectiveness_summary?.total_enforcement_decisions || 0],
        ["Top controls listed", (report.control_effectiveness_summary?.top_controls || []).length],
        ["Counterfactual examples", report.counterfactual_summary?.example_count || 0],
        ["Evaluated requests", report.counterfactual_summary?.total_requests_analyzed || 0]
      ]);
      $("dataset").innerHTML = evidenceRows([
        ["Dataset Rows", dataset.row_count || 0],
        ["Raw Prompt Text Included", yesNo(Boolean(dataset.raw_prompt_text_included))],
        ["Prompt-safe Export", dataset.admin_only ? "Admin-only" : "Available"],
        ["Columns", (dataset.columns || []).length]
      ]) + (dataset.message ? `<p class="summary-copy">${escHtml(dataset.message)}</p>` : "");
      const privacy = report.privacy || {};
      $("privacySummary").innerHTML = evidenceRows([
        ["Raw prompt text stored", yesNo(Boolean(privacy.raw_prompt_text_stored))],
        ["Prompt hashes used", yesNo(privacy.uses_prompt_hashes !== false)],
        ["Dataset export is prompt-safe", yesNo(privacy.dataset_export_is_prompt_safe !== false)]
      ]);
      const nextSteps = [
        "Run benign, suspicious, injection, extraction, jailbreak, and cross-model test suites.",
        "Export the research-safe evaluation dataset for dissertation tables.",
        "Compare current, stricter, and relaxed policy modes.",
        "Use counterfactual replay to measure adaptive controls."
      ];
      $("nextSteps").innerHTML = nextSteps.map((step) => `<li>${escHtml(step)}</li>`).join("");
      $("status").style.display = "none";
    }
    $("reloadBtn").addEventListener("click", load);
    document.querySelectorAll(".tab").forEach((tab) => tab.addEventListener("click", () => setTab(tab.dataset.tab)));
    setTab(new URLSearchParams(location.search).get("tab") || "test-suite");
    load().catch((err) => {
      $("status").style.display = "block";
      $("status").textContent = String(err.message || err);
    });
  </script>
</body>
</html>
""".replace("</style>", f"{CYBER_UI_CSS}\n  </style>").replace("</body>", f"{CYBER_UI_JS}\n</body>")
