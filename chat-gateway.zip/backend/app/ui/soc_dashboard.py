from app.ui.common import CYBER_UI_CSS, CYBER_UI_JS


SOC_DASHBOARD_HTML = """
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Security Observability — Zero Trust AI Gateway</title>
  <style>
    :root { color-scheme: dark; font-family: Inter, ui-sans-serif, system-ui; --muted:#9ca8bd; --good:#34d399; --warn:#fbbf24; --bad:#fb7185; }
    * { box-sizing: border-box; }
    body { margin: 0; min-height: 100vh; color: #f8fbff; background: #050505; }
    .shell { padding: 18px; display: grid; gap: 14px; }
    .top { display:flex; gap:10px; flex-wrap:wrap; align-items:center; justify-content:space-between; }
    .row { display:flex; gap:8px; flex-wrap:wrap; align-items:center; }
    a,button { border:1px solid rgba(255,255,255,.15); border-radius:999px; padding:9px 12px; color:#f8fbff; background:rgba(255,255,255,.06); text-decoration:none; cursor:pointer; }
    .grid { display:grid; grid-template-columns: repeat(2, minmax(280px, 1fr)); gap: 14px; }
    .summary { display:grid; grid-template-columns: repeat(3, minmax(140px,1fr)); gap:10px; }
    .kpi { border:1px solid rgba(255,255,255,.12); border-radius:14px; padding:10px; background:rgba(255,255,255,.04); }
    .kpi b { display:block; font-size:22px; margin-top:4px; }
    .card { border:1px solid rgba(255,255,255,.12); border-radius:16px; background:rgba(255,255,255,.05); padding:12px; min-height:220px; }
    .title { font-size:13px; color:#93c5fd; text-transform:uppercase; letter-spacing:.06em; margin-bottom:8px; }
    .muted { color: var(--muted); font-size: 12px; }
    .list { display:grid; gap:8px; max-height:300px; overflow:auto; }
    .item { border:1px solid rgba(255,255,255,.11); border-radius:12px; padding:10px; background:rgba(0,0,0,.26); transition: transform .2s ease, opacity .2s ease; }
    .item:hover { transform: translateY(-2px); }
    .badge { border:1px solid rgba(255,255,255,.16); border-radius:999px; padding:4px 7px; font-size:11px; }
    .high { color: var(--bad); border-color: rgba(251,113,133,.6); background: rgba(251,113,133,.14); animation: pulse 1.8s infinite; }
    .medium { color: var(--warn); border-color: rgba(251,191,36,.55); background: rgba(251,191,36,.1); }
    .low { color: #93c5fd; border-color: rgba(147,197,253,.45); background: rgba(147,197,253,.1); }
    .live { display:inline-flex; align-items:center; gap:6px; font-size:12px; color:#86efac; }
    .live-dot { width:8px; height:8px; border-radius:50%; background:#22c55e; animation: pulse 1.4s infinite; }
    .skeleton { border-radius:12px; background: linear-gradient(90deg, rgba(255,255,255,.04), rgba(255,255,255,.1), rgba(255,255,255,.04)); background-size: 200% 100%; animation: shimmer 1.2s infinite; }
    .skeleton.row { height: 44px; margin-bottom: 8px; }
    .state { border:1px dashed rgba(255,255,255,.18); border-radius:12px; padding:12px; color:var(--muted); text-align:center; }
    .fade { animation: fade .22s ease; }
    .heat { display:grid; grid-template-columns: repeat(6, minmax(90px,1fr)); gap:8px; }
    .heat-cell { border-radius:12px; padding:10px; border:1px solid rgba(255,255,255,.12); }
    .table { width:100%; border-collapse: collapse; font-size:12px; }
    .table th,.table td { text-align:left; padding:8px; border-bottom:1px solid rgba(255,255,255,.08); vertical-align: top; }
    canvas { width:100%; height:200px; background:rgba(0,0,0,.18); border-radius:12px; border:1px solid rgba(255,255,255,.08); }
    @keyframes pulse { 0%,100%{ box-shadow:0 0 0 rgba(251,113,133,0);} 50%{ box-shadow:0 0 22px rgba(251,113,133,.25);} }
    @keyframes shimmer { 0%{background-position:200% 0} 100%{background-position:-200% 0} }
    @keyframes fade { from { opacity:.5; } to { opacity:1; } }
    @media (max-width: 980px) {
      .grid { grid-template-columns: 1fr; }
      .heat { grid-template-columns: repeat(3, minmax(0, 1fr)); }
      .summary { grid-template-columns: repeat(3, 1fr); }
    }
    @media (max-width: 640px) {
      .heat { grid-template-columns: repeat(2, 1fr); }
      .summary { grid-template-columns: repeat(2, 1fr); }
      .top { flex-direction: column; align-items: flex-start; gap: 8px; }
      /* Table scrolls, doesn't break layout */
      .table { display: block; overflow-x: auto; -webkit-overflow-scrolling: touch; white-space: nowrap; }
      .table th, .table td { white-space: nowrap; }
      canvas { height: 160px !important; }
    }
    @media (max-width: 420px) {
      .heat { grid-template-columns: repeat(2, 1fr); }
      .summary { grid-template-columns: 1fr; }
      .kpi b { font-size: 18px; }
      .heat-cell { padding: 8px; }
    }
  </style>
</head>
<body>
  <main class="shell">
    <section class="top">
      <div>
        <div class="title">Security Observability for AI Inference Decisions</div>
        <h1 class="m-0">Security Observability</h1>
      </div>
      <div class="row">
        <span class="live" id="liveStatus"><span class="live-dot"></span>Live</span>
        <a href="/dashboard">Dashboard</a>
        <a href="/dashboard/policy">Policy Engine</a>
        <button id="refreshBtn">Refresh</button>
      </div>
    </section>

    <section class="grid">
      <article class="card min-h-[120px]">
        <div class="title">Recent Decisions</div>
        <div class="summary">
          <div class="kpi"><span class="muted">Risk Events</span><b id="kpiAttacks">--</b></div>
          <div class="kpi"><span class="muted">Blocked</span><b id="kpiBlocked">--</b></div>
          <div class="kpi"><span class="muted">High risk</span><b id="kpiHighRisk">--</b></div>
        </div>
      </article>
      <article class="card min-h-[120px]">
        <div class="title">Model Risk Events</div>
        <div class="summary">
          <div class="kpi"><span class="muted">Last self-test</span><b id="kpiTestStatus">--</b></div>
          <div class="kpi"><span class="muted">Passed</span><b id="kpiTestPassed">--</b></div>
          <div class="kpi"><span class="muted">Failed</span><b id="kpiTestFailed">--</b></div>
        </div>
      </article>
      <article class="card">
        <div class="title">Decision Trace Timeline</div>
        <canvas id="timelineCanvas" width="1200" height="400"></canvas>
      </article>
      <article class="card">
        <div class="title">Cross-Model Abuse Indicators</div>
        <div id="heatmap" class="heat muted"></div>
      </article>
      <article class="card">
        <div class="title">User Trust Changes</div>
        <div class="max-h-[300px] overflow-auto">
          <table class="table"><thead><tr><th>User</th><th>Trust Score</th><th>Flags</th></tr></thead><tbody id="anomalyRows"></tbody></table>
        </div>
      </article>
      <article class="card">
        <div class="title">Blocked and Challenged Requests</div>
        <div id="alerts" class="list muted"></div>
      </article>
    </section>
  </main>
  <script>
    const api = "/api/v1";
    const token = sessionStorage.getItem("zta_token");
    if (!token) location.href = "/login?next=/dashboard/security-monitor";
    const headers = () => ({ Authorization: `Bearer ${token}` });

    async function get(path) {
      const res = await fetch(path, { headers: headers() });
      const text = await res.text();
      let data; try { data = text ? JSON.parse(text) : {}; } catch { data = {}; }
      if (!res.ok) throw new Error((data.detail && data.detail.message) || data.detail || `Request failed (${res.status})`);
      return data;
    }

    /* ---- Mock data fallbacks ---- */
    function mockTimeline() {
      const stages = ['allow','block','allow','block','allow','allow','block','allow','block','allow',
                      'block','allow','allow','block','allow','allow','block','allow','block','allow'];
      return stages.map((d, i) => ({
        sequence_severity: parseFloat((Math.random() * 0.85 + (d === 'block' ? 0.1 : 0)).toFixed(2)),
        decision: d,
        timestamp: new Date(Date.now() - i * 85000).toISOString()
      }));
    }
    function mockHeatmapCells() {
      const stages = ['Prompt Inject','Jailbreak','Data Leak','PII Probe','Model Abuse','Rate Abuse'];
      return stages.map((s, i) => ({
        attack_stage: s,
        count: Math.floor(Math.random() * 40) + 3,
        model_id: i + 1
      }));
    }
    function mockAnomalies() {
      return [
        { username: 'user_4', trust_score: 0.29, anomaly_flags: ['repeated probing', 'high frequency'] },
        { username: 'api_client_7', trust_score: 0.48, anomaly_flags: ['suspicious query patterns'] }
      ];
    }
    function mockAlerts() {
      return [
        { severity: 'high', type: 'prompt_injection', message: 'Prompt injection attempt detected in session', timestamp: new Date().toISOString() },
        { severity: 'medium', type: 'behavior_anomaly', message: 'Repeated probing behavior from user_4', timestamp: new Date(Date.now()-180000).toISOString() },
        { severity: 'low', type: 'rate_limit', message: 'Rate limit threshold approached for api_client_7', timestamp: new Date(Date.now()-420000).toISOString() }
      ];
    }

    let _usingMock = false;
    async function safeGet(path, fallback) {
      try { return await get(path); }
      catch { _usingMock = true; return fallback; }
    }

    let lastHash = "";
    const orderWeight = (s) => { const v = String(s||"").toLowerCase(); return v==="critical"||v==="high"?0:v==="warning"||v==="medium"?1:2; };
    function sevClass(s) { const v = String(s||"").toLowerCase(); return v==="critical"||v==="high"?"high":v==="warning"||v==="medium"?"medium":"low"; }

    function drawTimeline(events) {
      const canvas = document.getElementById("timelineCanvas");
      const ctx = canvas.getContext("2d");
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const points = (events || []).slice(0, 60).reverse();
      if (!points.length) return;
      const values = points.map((e) => Number(e.sequence_severity || 0));
      const w = canvas.width, h = canvas.height, pad = 40;
      /* gradient fill */
      const grad = ctx.createLinearGradient(0, 0, 0, h);
      grad.addColorStop(0, "rgba(147,197,253,.28)");
      grad.addColorStop(1, "rgba(147,197,253,0)");
      ctx.beginPath();
      values.forEach((v, i) => {
        const x = pad + (i / Math.max(1, values.length - 1)) * (w - pad * 2);
        const y = h - pad - (Math.max(0, Math.min(1, v)) * (h - pad * 2));
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      });
      ctx.lineTo(pad + (values.length-1)/(Math.max(1,values.length-1))*(w-pad*2), h-pad);
      ctx.lineTo(pad, h-pad);
      ctx.closePath();
      ctx.fillStyle = grad;
      ctx.fill();
      /* line */
      ctx.beginPath();
      values.forEach((v, i) => {
        const x = pad + (i / Math.max(1, values.length - 1)) * (w - pad * 2);
        const y = h - pad - (Math.max(0, Math.min(1, v)) * (h - pad * 2));
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      });
      ctx.strokeStyle = "rgba(147,197,253,.92)";
      ctx.lineWidth = 3;
      ctx.stroke();
    }

    function setLoading() {
      document.getElementById("alerts").innerHTML = `<div class="skeleton row"></div><div class="skeleton row"></div><div class="skeleton row"></div>`;
      document.getElementById("heatmap").innerHTML = `<div class="skeleton row"></div><div class="skeleton row"></div>`;
      document.getElementById("anomalyRows").innerHTML = `<tr><td colspan="3"><div class="skeleton row"></div></td></tr>`;
    }
    function animatedSet(id, next) {
      const el = document.getElementById(id);
      if (!el) return;
      const prev = Number(el.textContent || 0);
      const target = Number(next || 0);
      if (Number.isNaN(prev) || Number.isNaN(target) || prev === target) { el.textContent = String(next); return; }
      const start = performance.now(), dur = 220;
      const tick = (t) => {
        const p = Math.min(1, (t - start) / dur);
        el.textContent = String(Math.round(prev + (target - prev) * p));
        if (p < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    }

    async function load() {
      _usingMock = false;
      const [timeline, heatmap, anomalies, alerts] = await Promise.all([
        safeGet(`${api}/monitoring/soc/attack-timeline?limit=120`, { events: mockTimeline() }),
        safeGet(`${api}/monitoring/soc/threat-heatmap`, { cells: mockHeatmapCells() }),
        safeGet(`${api}/monitoring/soc/user-anomalies`, { anomalies: mockAnomalies() }),
        safeGet(`${api}/monitoring/soc/alerts`, { alerts: mockAlerts() })
      ]);

      const currentHash = JSON.stringify({ timeline, heatmap, anomalies, alerts });
      if (currentHash === lastHash) return;
      lastHash = currentHash;

      const events = timeline.events || [];
      const highRisk = events.filter((e) => Number(e.sequence_severity || 0) >= 0.7).length;
      animatedSet("kpiAttacks", events.length);
      animatedSet("kpiBlocked", events.filter((e) => String(e.decision || "").toLowerCase() === "block").length);
      animatedSet("kpiHighRisk", highRisk);

      drawTimeline(events);

      const max = Math.max(1, ...((heatmap.cells || []).map((c) => Number(c.count || 0))));
      document.getElementById("heatmap").innerHTML = (heatmap.cells || []).slice(0, 24).map((c) => {
        const ratio = Number(c.count || 0) / max;
        const alpha = (0.18 + ratio * 0.7).toFixed(2);
        return `<div class="heat-cell fade" style="background:rgba(251,113,133,${alpha})"><div class="muted">${c.attack_stage}</div><strong>${c.count}</strong><div class="muted">model ${c.model_id ?? "-"}</div></div>`;
      }).join("") || `<div class="state">No threats detected · System secure</div>`;

      document.getElementById("anomalyRows").innerHTML = (anomalies.anomalies || []).map((a) =>
        `<tr class="fade"><td>${a.username}</td><td>${Number(a.trust_score || 0).toFixed(2)}</td><td>${(a.anomaly_flags || []).join(", ")}</td></tr>`
      ).join("") || `<tr><td colspan="3" class="muted">No anomalies</td></tr>`;

      const sorted = (alerts.alerts || []).slice(0, 60).sort((a, b) => orderWeight(a.severity) - orderWeight(b.severity));
      document.getElementById("alerts").innerHTML = sorted.map((a) =>
        `<div class="item fade"><div class="row"><span class="badge ${sevClass(a.severity)}">${a.severity || "info"}</span><b>${a.type || "alert"}</b></div><div class="muted" style="margin-top:6px">${a.message || ""}</div><div class="muted" style="margin-top:6px">${a.timestamp || ""}</div></div>`
      ).join("") || `<div class="state">No threats detected · System secure</div>`;

      /* update live status indicator */
      const livEl = document.getElementById("liveStatus");
      if (livEl) {
        livEl.innerHTML = _usingMock
          ? `<span style="color:var(--warn);font-size:11px">No live data — showing simulated activity</span>`
          : `<span class="live-dot"></span>Live`;
      }
    }

    async function refreshSelfTestHealth() {
      try {
        const data = await get(`${api}/testing/run-soc-tests`);
        const failed = Number(data.failed || 0);
        document.getElementById("kpiTestStatus").textContent = failed > 0 ? "Failing" : "Passing";
        document.getElementById("kpiTestPassed").textContent = String(data.passed ?? 0);
        document.getElementById("kpiTestFailed").textContent = String(data.failed ?? 0);
      } catch {
        document.getElementById("kpiTestStatus").textContent = "Unavailable";
        document.getElementById("kpiTestPassed").textContent = "--";
        document.getElementById("kpiTestFailed").textContent = "--";
      }
    }

    let timer = null;
    function boot() {
      setLoading();
      load();
      refreshSelfTestHealth();
      timer = setInterval(() => load(), 4000);
    }
    document.getElementById("refreshBtn").addEventListener("click", () => load());
    window.addEventListener("beforeunload", () => { if (timer) clearInterval(timer); });
    boot();
  </script>
</body>
</html>
""".replace("</style>", f"{CYBER_UI_CSS}\n  </style>").replace("</body>", f"{CYBER_UI_JS}\n</body>")
