CYBER_UI_CSS = """

    /* Shared Zero Trust AI Gateway UI primitives. The global layer deliberately
       calms older page-specific styling so the product reads as a focused
       MSc research prototype instead of a cyberpunk enterprise console. */
    :root {
      --zt-bg: #070a0f;
      --zt-bg-soft: #0b111a;
      --zt-panel: rgba(15, 23, 42, .72);
      --zt-panel-strong: rgba(17, 24, 39, .9);
      --zt-border: rgba(148, 163, 184, .2);
      --zt-border-hot: rgba(56, 189, 248, .42);
      --zt-text: #eef5ff;
      --zt-muted: #94a3b8;
      --zt-cyan: #38bdf8;
      --zt-purple: #8b5cf6;
      --zt-blue: #60a5fa;
      --zt-green: #22c55e;
      --zt-yellow: #f59e0b;
      --zt-red: #f43f5e;
      --zt-radius: 10px;
      --zt-fast: 220ms cubic-bezier(.2, .8, .2, 1);
      --zt-sidebar-w: 240px;
      --zt-topbar-h: 60px;
    }
    *, *::before, *::after { box-sizing: border-box; }
    .hidden { display: none !important; }
    html {
      background: var(--zt-bg);
      min-width: 0;
      overflow-x: hidden;
      -webkit-text-size-adjust: 100%;
      text-size-adjust: 100%;
    }
    body {
      margin: 0;
      min-width: 0;
      overflow-x: hidden;
      background:
        radial-gradient(circle at 18% 0%, rgba(56, 189, 248, .12), transparent 28%),
        linear-gradient(180deg, #080b11 0%, #0b111a 42%, #070a0f 100%) !important;
      color: var(--zt-text) !important;
      font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif !important;
    }
    img, canvas, svg, video { max-width: 100%; height: auto; }
    table { max-width: 100%; }
    pre, code, textarea, input, select, button, a { max-width: 100%; }
    input, textarea, select, button { font-size: 16px; }
    .shell, .app, .wrap, header, main, section, article, aside, .panel, .card, .stat, .metric, .status-card {
      min-width: 0;
    }
    .shell, .wrap {
      width: min(1440px, calc(100% - 28px));
      margin-inline: auto;
    }
    body:not(.zt-with-shell) .shell,
    body:not(.zt-with-shell) .wrap {
      padding-inline: clamp(10px, 2vw, 22px);
    }
    .grid, .stats, .metrics, .summary, .wide, .layout, .cc-grid, .soc-grid, .metric-grid, .kpi-grid, .split, .flow, #cardView {
      min-width: 0;
    }
    .row, .actions, .nav-row, header, .chat-head, .input-row {
      min-width: 0;
    }
    .row > *, .actions > *, .nav-row > * {
      min-width: 0;
    }
    .row input, .row textarea, .row select,
    .actions input, .actions textarea, .actions select {
      flex: 1 1 220px !important;
      min-width: min(220px, 100%) !important;
    }
    body::before {
      content: "";
      position: fixed;
      inset: 0;
      pointer-events: none;
      z-index: 0;
      background-image: linear-gradient(rgba(148,163,184,.055) 1px, transparent 1px) !important;
      background-size: 100% 42px !important;
      opacity: .55 !important;
      mask-image: linear-gradient(to bottom, rgba(0,0,0,.7), rgba(0,0,0,.05)) !important;
    }
    body::after {
      display: none !important;
    }
    .shell, .app, .wrap { position: relative; z-index: 1; animation: ztFadeIn .28s ease both; }
    body.zt-with-shell .shell,
    body.zt-with-shell .wrap,
    body.zt-with-shell .app {
      margin-left: calc(var(--zt-sidebar-w) + 12px) !important;
      margin-top: calc(var(--zt-topbar-h) + 14px) !important;
      width: calc(100% - var(--zt-sidebar-w) - 24px) !important;
    }
    body.zt-with-shell .app {
      height: calc(100vh - var(--zt-topbar-h) - 24px) !important;
    }
    .zt-sidebar {
      position: fixed;
      left: 12px;
      top: 12px;
      bottom: 12px;
      width: var(--zt-sidebar-w);
      z-index: 20;
      border: 1px solid var(--zt-border);
      border-radius: 12px;
      background: rgba(8, 13, 21, .94);
      backdrop-filter: blur(10px);
      box-shadow: none;
      display: grid;
      grid-template-rows: auto 1fr auto;
      padding: 14px 10px;
      gap: 12px;
    }
    .zt-brand {
      padding: 6px 10px 10px;
      border-bottom: 1px solid rgba(255,255,255,.08);
    }
    .zt-brand b {
      display: block;
      font-size: 13px;
      color: #c4b5fd;
      letter-spacing: .02em;
    }
    .zt-brand span {
      display: block;
      color: var(--zt-muted);
      font-size: 11px;
      margin-top: 4px;
    }
    .zt-nav { display: grid; gap: 6px; align-content: start; padding: 0 4px; }
    .zt-nav a {
      display: flex;
      align-items: center;
      min-width: 0;
      gap: 9px;
      border-radius: 8px !important;
      padding: 9px 10px !important;
      font-size: 13px;
      border: 1px solid rgba(255,255,255,.1) !important;
      background: transparent !important;
      box-shadow: none !important;
      transform: none !important;
      text-decoration: none;
    }
    .zt-nav a span {
      min-width: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .zt-nav a.zt-active {
      border-color: rgba(56,189,248,.42) !important;
      background: rgba(56,189,248,.1) !important;
      box-shadow: none !important;
    }
    .zt-status {
      margin: 0 4px;
      padding: 10px;
      border-top: 1px solid rgba(255,255,255,.08);
      display: grid;
      gap: 8px;
    }
    .zt-status .zt-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      display: inline-block;
      margin-right: 6px;
      box-shadow: 0 0 14px currentColor;
    }
    .zt-status .good { color: var(--zt-green); }
    .zt-status .warn { color: var(--zt-yellow); }
    .zt-status .bad { color: var(--zt-red); }
    .zt-topbar {
      position: fixed;
      left: calc(var(--zt-sidebar-w) + 24px);
      right: 12px;
      top: 12px;
      height: var(--zt-topbar-h);
      z-index: 19;
      border: 1px solid var(--zt-border);
      border-radius: 10px;
      background: rgba(8, 13, 21, .92);
      backdrop-filter: blur(10px);
      box-shadow: none;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      padding: 8px 12px;
    }
    .zt-topbar h3 {
      margin: 0;
      min-width: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      font-size: 15px;
      color: #e2e8f0;
      font-weight: 700;
    }
    .zt-topbar .meta { display: flex; gap: 8px; flex-wrap: wrap; }
    .zt-chip {
      border: 1px solid rgba(255,255,255,.14);
      border-radius: 999px;
      padding: 4px 8px;
      font-size: 11px;
      color: #cbd5e1;
      background: rgba(255,255,255,.05);
      white-space: nowrap;
    }
    header, .chat-head, .card, .panel, .stat, .metric, .status-card {
      overflow-wrap: anywhere;
    }
    header, .chat-head {
      border: 1px solid var(--zt-border) !important;
      border-radius: var(--zt-radius) !important;
      background: rgba(15, 23, 42, .66) !important;
      backdrop-filter: blur(10px) !important;
      box-shadow: none !important;
      padding: 16px !important;
    }
    .panel, .stat, .card, .metric, .status-card, .session, .bubble, pre, input, textarea, select, .pill {
      border: 1px solid var(--zt-border) !important;
      border-radius: var(--zt-radius) !important;
      background: var(--zt-panel) !important;
      box-shadow: none !important;
    }
    .panel, header, .chat-head { backdrop-filter: blur(14px) !important; }
    .card, .stat, .metric, .status-card, .session, .bubble, pre, input, textarea, select, .pill {
      backdrop-filter: none !important;
    }
    .panel::after, .stat::after, .card::after {
      display: none !important;
    }
    .card, .stat, .metric, .status-card, .session, .bubble {
      transition: transform var(--zt-fast), border-color var(--zt-fast), box-shadow var(--zt-fast), background var(--zt-fast);
    }
    .card:hover, .stat:hover, .metric:hover, .status-card:hover, .session:hover {
      transform: none !important;
      border-color: var(--zt-border-hot) !important;
      box-shadow: none !important;
    }
    .session.active, .tab.active {
      border-color: rgba(168,85,247,.62) !important;
      background: rgba(168,85,247,.13) !important;
      box-shadow: 0 0 28px rgba(168,85,247,.16), inset 0 1px 0 rgba(255,255,255,.08) !important;
    }
    h1, h2, .eyebrow, .label, .id {
      text-shadow: none !important;
      letter-spacing: 0 !important;
    }
    h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      color: var(--zt-text) !important;
      text-transform: none !important;
    }
    h2, .eyebrow, .label, .id { color: #93c5fd !important; }
    p, .muted, small, .meta { color: var(--zt-muted) !important; }
    a, button {
      border: 1px solid rgba(34,211,238,.22) !important;
      border-radius: 8px !important;
      background: rgba(15, 23, 42, .78) !important;
      color: var(--zt-text) !important;
      box-shadow: none !important;
      transition: transform var(--zt-fast), box-shadow var(--zt-fast), border-color var(--zt-fast), filter var(--zt-fast) !important;
    }
    a:hover, button:hover {
      transform: none !important;
      border-color: rgba(34,211,238,.62) !important;
      box-shadow: none !important;
    }
    button.primary, #sendBtn, .actions button:not(.secondary) {
      background: #e2e8f0 !important;
      color: #07111f !important;
      font-weight: 750 !important;
    }
    .danger {
      border-color: rgba(251,113,133,.42) !important;
      background: rgba(251,113,133,.12) !important;
      color: #fecdd3 !important;
    }
    input:focus, textarea:focus, select:focus {
      border-color: rgba(34,211,238,.68) !important;
      box-shadow: 0 0 0 3px rgba(34,211,238,.12) !important;
    }
    .badge, .pill, .status-badge {
      border: 1px solid rgba(255,255,255,.14) !important;
      border-radius: 999px !important;
      background: rgba(255,255,255,.06) !important;
      color: var(--zt-text) !important;
    }
    .allow, [data-decision="allow"], .badge.allow {
      color: var(--zt-green) !important;
      border-color: rgba(52,211,153,.45) !important;
      box-shadow: none !important;
    }
    .challenge, [data-decision="challenge"], .badge.challenge {
      color: var(--zt-yellow) !important;
      border-color: rgba(251,191,36,.48) !important;
      box-shadow: none !important;
    }
    .block, [data-decision="block"], .badge.block, .bad {
      color: var(--zt-red) !important;
      border-color: rgba(251,113,133,.5) !important;
      box-shadow: none !important;
      animation: none !important;
    }
    .ready { border-color: rgba(52,211,153,.44) !important; }
    .warn, .medium { border-color: rgba(251,191,36,.5) !important; }
    .high, .critical { border-color: rgba(251,113,133,.55) !important; animation: none !important; }
    .value, .metric strong, .metric b {
      color: #f8fbff !important;
      font-variant-numeric: tabular-nums;
    }
    pre {
      color: #dbeafe !important;
      line-height: 1.55 !important;
      overflow-x: auto !important;
    }
    .zt-trace-step {
      display: block;
      opacity: 0;
      transform: translateY(4px);
      animation: ztStep .24s ease forwards;
    }
    .zt-log-card { animation: ztFadeIn .18s ease both; }
    .dot { box-shadow: none !important; }
    @keyframes ztFadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes ztStep { to { opacity: 1; transform: translateY(0); } }
    @keyframes ztPulse {
      0%, 100% { box-shadow: 0 0 18px rgba(251,113,133,.13), inset 0 1px 0 rgba(255,255,255,.06) !important; }
      50% { box-shadow: 0 0 34px rgba(251,113,133,.34), 0 0 56px rgba(251,113,133,.16) !important; }
    }
    @keyframes ztSweep { to { transform: translate3d(24px, -18px, 0); } }
    @media (prefers-reduced-motion: reduce) {
      *, *::before, *::after { animation-duration: .001ms !important; transition-duration: .001ms !important; }
    }

    /* ── Tablet + mobile (≤ 980 px): sidebar → bottom tab bar ── */
    @media (max-width: 980px) {
      :root {
        --zt-topbar-h: 52px;
        --zt-mobile-nav-h: 74px;
      }
      html, body { overflow-x: hidden !important; }
      body.zt-with-shell {
        padding-bottom: calc(var(--zt-mobile-nav-h) + env(safe-area-inset-bottom, 0px)) !important;
      }
      /* All main content areas: clear topbar above, nav bar below */
      body.zt-with-shell .shell,
      body.zt-with-shell .wrap,
      body.zt-with-shell .app,
      body.zt-with-shell > main {
        margin-left: 0 !important;
        margin-right: 0 !important;
        margin-top: calc(var(--zt-topbar-h) + 10px) !important;
        width: 100% !important;
        max-width: 100% !important;
      }
      body.zt-with-shell .shell,
      body.zt-with-shell .wrap {
        padding-left: 12px !important;
        padding-right: 12px !important;
        padding-bottom: calc(var(--zt-mobile-nav-h) + 16px) !important;
      }
      /* Fixed-height app containers (e.g. chat) */
      body.zt-with-shell .app {
        height: calc(100svh - var(--zt-topbar-h) - var(--zt-mobile-nav-h) - 20px) !important;
        min-height: unset !important;
        padding-left: 10px !important;
        padding-right: 10px !important;
      }
      /* Topbar: full-width strip at top */
      .zt-topbar {
        left: 10px !important;
        right: 10px !important;
        top: max(10px, env(safe-area-inset-top, 0px)) !important;
        height: var(--zt-topbar-h) !important;
        border-radius: 14px !important;
        padding: 7px 12px !important;
      }
      .zt-topbar h3 { font-size: 13px; }
      .zt-topbar .meta { display: none; }
      /* Sidebar becomes bottom tab bar */
      .zt-sidebar {
        left: 10px !important;
        right: 10px !important;
        top: auto !important;
        bottom: max(10px, env(safe-area-inset-bottom, 0px)) !important;
        width: auto !important;
        height: var(--zt-mobile-nav-h) !important;
        border-radius: 18px !important;
        display: block !important;
        padding: 6px !important;
        overflow: hidden !important;
      }
      .zt-brand, .zt-status { display: none !important; }
      .zt-nav {
        height: 100%;
        display: flex !important;
        align-items: stretch;
        gap: 4px;
        overflow-x: auto;
        overflow-y: hidden;
        padding: 0 2px !important;
        scroll-snap-type: x mandatory;
        -webkit-overflow-scrolling: touch;
        scrollbar-width: none;
      }
      .zt-nav::-webkit-scrollbar { display: none; }
      /* Tab items: icon stacked above label */
      .zt-nav a {
        flex: 0 0 64px;
        min-width: 64px;
        height: 100%;
        flex-direction: column !important;
        justify-content: center;
        align-items: center;
        gap: 3px !important;
        padding: 6px 4px !important;
        scroll-snap-align: center;
        border-radius: 12px !important;
        min-height: unset !important;
      }
      .zt-nav a b { font-size: 18px; line-height: 1; }
      /* Show tiny labels on tablets so icons are identifiable */
      .zt-nav a span {
        display: block !important;
        font-size: 9px !important;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        max-width: 58px;
        color: var(--zt-muted);
        letter-spacing: 0;
      }
      .zt-nav a.zt-active span { color: #67e8f9; }
      /* Grid: wide layouts collapse */
      .grid, .summary, .wide, .layout, .cc-grid, .soc-grid, .metric-grid, .split, .flow, #cardView {
        grid-template-columns: 1fr !important;
      }
      .stats, .metrics, .kpi-grid {
        grid-template-columns: repeat(2, 1fr) !important;
      }
      .heat {
        grid-template-columns: repeat(3, minmax(0, 1fr)) !important;
      }
      body::before { background-size: 48px 48px !important; opacity: .28 !important; }
    }

    /* ── Phone (≤ 640 px): full single-column, touch-friendly ── */
    @media (max-width: 640px) {
      body.zt-with-shell .shell,
      body.zt-with-shell .wrap {
        padding-left: 10px !important;
        padding-right: 10px !important;
      }
      .grid, .stats, .metrics, .summary, .wide, .layout, .cc-grid, .soc-grid,
      .metric-grid, .kpi-grid, .split, .flow, #cardView, .heat {
        grid-template-columns: 1fr !important;
      }
      /* Tables scroll horizontally without breaking layout */
      .table-wrap {
        overflow-x: auto !important;
        -webkit-overflow-scrolling: touch;
        max-width: 100%;
      }
      header, .chat-head { border-radius: 14px !important; padding: 10px !important; }
      .panel, .stat, .card, .metric, .status-card, .session, .bubble {
        border-radius: 14px !important;
      }
      .row, .actions, .nav-row { gap: 7px; }
      /* Larger tap targets for buttons/links — but NOT the tab bar */
      button, a { min-height: 42px; }
      .zt-nav a { min-height: unset !important; }
      h1 { font-size: clamp(22px, 9vw, 36px) !important; }
      h2 { font-size: clamp(14px, 5vw, 20px) !important; }
    }

    /* ── Small phones (≤ 420 px): icons only in tab bar ──────── */
    @media (max-width: 420px) {
      :root { --zt-mobile-nav-h: 68px; }
      .zt-sidebar { left: 6px !important; right: 6px !important; padding: 5px !important; }
      .zt-nav a { flex-basis: 54px; min-width: 54px; }
      .zt-nav a span { display: none !important; }
      body.zt-with-shell .shell,
      body.zt-with-shell .wrap,
      body.zt-with-shell .app {
        padding-inline: 8px !important;
        margin-top: calc(var(--zt-topbar-h) + 8px) !important;
      }
      h1 { font-size: clamp(20px, 8vw, 28px) !important; }
      .zt-chip { padding: 3px 6px; font-size: 10px; }
    }

    /* ── Ultrawide (≥ 1440 px): cap content width ────────────── */
    @media (min-width: 1440px) {
      body.zt-with-shell .shell,
      body.zt-with-shell .wrap,
      body.zt-with-shell .app {
        max-width: calc(1680px - var(--zt-sidebar-w));
        margin-right: auto !important;
      }
    }

    /* Auth pages: suppress sidebar and topbar */
    body.no-shell #ztSidebar,
    body.no-shell #ztTopbar,
    body.no-shell .zt-sidebar,
    body.no-shell .zt-topbar { display: none !important; }
    body.no-shell { padding-bottom: 0 !important; }

    /* Tailwind-backed component contracts used across all dashboard pages. */
    .zt-page-wrapper { max-width: 1440px; }
    .zt-section-card, .zt-metric-card {
      border: 1px solid rgba(255,255,255,.10) !important;
      border-radius: 16px !important;
      background: rgba(255,255,255,.05) !important;
    }
    .zt-section-card-highlight {
      border-color: rgba(56,189,248,.28) !important;
      background: rgba(14,165,233,.08) !important;
    }
    .zt-section-card-warning {
      border-color: rgba(245,158,11,.35) !important;
      background: rgba(245,158,11,.08) !important;
    }
    .zt-btn-primary {
      border-color: rgba(56,189,248,.45) !important;
      background: #e2e8f0 !important;
      color: #020617 !important;
      font-weight: 700 !important;
    }
    .zt-btn-secondary {
      border-color: rgba(255,255,255,.12) !important;
      background: rgba(255,255,255,.07) !important;
      color: #e2e8f0 !important;
    }
    .zt-btn-ghost {
      border-color: transparent !important;
      background: transparent !important;
      color: #cbd5e1 !important;
    }
    .zt-btn-danger {
      border-color: rgba(244,63,94,.35) !important;
      background: rgba(244,63,94,.12) !important;
      color: #fecdd3 !important;
    }
    .zt-input {
      border: 1px solid rgba(255,255,255,.12) !important;
      border-radius: 12px !important;
      background: rgba(2,6,23,.62) !important;
      color: #f1f5f9 !important;
    }
    .zt-tab {
      border: 1px solid rgba(255,255,255,.10) !important;
      border-radius: 12px !important;
      background: rgba(255,255,255,.04) !important;
      color: #cbd5e1 !important;
    }
    .zt-tab-active, .tab.active {
      border-color: rgba(56,189,248,.45) !important;
      background: rgba(56,189,248,.12) !important;
      color: #f8fafc !important;
      box-shadow: none !important;
    }
    .zt-table {
      width: 100%;
      border-collapse: collapse;
      color: #cbd5e1;
    }
    .zt-table th, .zt-table td {
      border-bottom: 1px solid rgba(255,255,255,.08);
      padding: 10px 8px;
      text-align: left;
      vertical-align: top;
    }
    .zt-table th {
      color: #93c5fd;
      font-size: 11px;
      letter-spacing: .04em;
      text-transform: uppercase;
    }
    .zt-empty-state {
      border: 1px dashed rgba(255,255,255,.16) !important;
      border-radius: 16px !important;
      background: rgba(255,255,255,.04) !important;
      color: #94a3b8 !important;
    }
"""


CYBER_UI_JS = """
  <script>
    window.tailwind = window.tailwind || {};
    window.tailwind.config = {
      theme: {
        extend: {
          colors: {
            gateway: {
              bg: "#020617",
              panel: "rgba(255,255,255,.05)",
              cyan: "#38bdf8"
            }
          }
        }
      }
    };
  </script>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    (() => {
      const UI = {
        page: "zt-page-wrapper mx-auto w-full max-w-screen-2xl px-4 pb-10 text-slate-100 sm:px-6 lg:px-8",
        sectionCard: "zt-section-card rounded-2xl border border-white/10 bg-white/5 text-slate-100 shadow-none",
        metricCard: "zt-metric-card rounded-2xl border border-white/10 bg-white/5 p-4 text-slate-100",
        sidebarItem: "rounded-xl border border-white/10 px-3 py-2 text-sm text-slate-300 transition hover:bg-white/10",
        sidebarItemActive: "zt-active border-cyan-400/40 bg-cyan-400/10 text-slate-100",
        buttonPrimary: "zt-btn-primary inline-flex items-center justify-center rounded-xl border border-cyan-300/40 px-3 py-2 text-sm font-semibold",
        buttonSecondary: "zt-btn-secondary inline-flex items-center justify-center rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-slate-100 hover:bg-white/10",
        buttonGhost: "zt-btn-ghost inline-flex items-center justify-center rounded-xl px-3 py-2 text-sm text-slate-300 hover:bg-white/10",
        buttonDanger: "zt-btn-danger inline-flex items-center justify-center rounded-xl border border-rose-400/30 px-3 py-2 text-sm text-rose-100",
        input: "zt-input rounded-xl border border-white/10 bg-slate-950/60 px-3 py-2 text-slate-100 placeholder:text-slate-500 focus:border-cyan-300/60 focus:outline-none",
        tab: "zt-tab rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-slate-300 hover:bg-white/10",
        badge: "inline-flex items-center rounded-full border border-white/10 bg-white/5 px-2 py-1 text-xs text-slate-300",
        table: "zt-table w-full border-collapse text-sm text-slate-300",
        empty: "zt-empty-state rounded-2xl border border-dashed border-white/15 bg-white/5 p-4 text-slate-400"
      };
      const addClasses = (node, classText) => {
        if (!node || !classText) return;
        node.classList.add(...classText.split(/\\s+/).filter(Boolean));
      };
      const numericIds = new Set([
        "modelsValue", "controlsValue", "rulesValue", "logsValue", "eventsValue",
        "totalRequests", "blockedRequests", "challengedRequests", "blockRate",
        "trustScore", "promptRisk", "securityScore"
      ]);
      const decisionClass = (value) => {
        const text = String(value || "").toLowerCase();
        if (text.includes("block")) return "block";
        if (text.includes("challenge")) return "challenge";
        if (text.includes("allow") || text.includes("protected") || text.includes("ready")) return "allow";
        return "";
      };
      /* Decode JWT payload (public base64 claims — not secret) */
      const parseJwt = (token) => {
        try {
          const b64 = token.split(".")[1].replace(/-/g, "+").replace(/_/g, "/");
          return JSON.parse(atob(b64));
        } catch { return {}; }
      };
      const getTokenPayload = () => {
        const t = sessionStorage.getItem("zta_token");
        return t ? parseJwt(t) : {};
      };
      const isAdmin = () => (getTokenPayload().scopes || []).includes("admin");

      /* All nav items — adminOnly=true hides from regular users */
      const NAV_ITEMS_ALL = [
        { href: "/dashboard",                  label: "Dashboard",           icon: "⌂", adminOnly: false },
        { href: "/dashboard/chat",             label: "Secure Chat",         icon: "◉", adminOnly: false },
        { href: "/dashboard/models",           label: "Models",              icon: "▦", adminOnly: false },
        { href: "/dashboard/security-monitor", label: "Security Monitor",    icon: "◈", adminOnly: false },
        { href: "/dashboard/policy",           label: "Policy Engine",       icon: "⚙", adminOnly: false },
        { href: "/dashboard/research",         label: "Research Evaluation", icon: "▧", adminOnly: false },
        { href: "/dashboard/account",          label: "Account",             icon: "◐", adminOnly: false },
      ];
      const NAV_ITEMS = NAV_ITEMS_ALL.filter(item => !item.adminOnly || isAdmin());
      const decorateDecision = (node) => {
        if (!node) return;
        node.classList.remove("allow", "challenge", "block");
        const cls = decisionClass(node.textContent);
        if (cls) {
          node.classList.add(cls);
          node.dataset.decision = cls;
        }
      };
      const animateNumber = (node, value) => {
        if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
        const raw = String(value || "").trim();
        const match = raw.match(/^([0-9]+(?:\\.[0-9]+)?)(%)?$/);
        if (!match) return;
        if (node.dataset.ztAnimating === "1" || node.dataset.ztLastValue === raw) return;
        const target = Number(match[1]);
        const suffix = match[2] || "";
        const start = Number(node.dataset.currentValue || 0);
        const startTime = performance.now();
        const duration = 180;
        node.dataset.ztAnimating = "1";
        const tick = (time) => {
          const t = Math.min(1, (time - startTime) / duration);
          const eased = 1 - Math.pow(1 - t, 3);
          const next = start + (target - start) * eased;
          node.textContent = `${target % 1 ? next.toFixed(2) : Math.round(next)}${suffix}`;
          if (t < 1) requestAnimationFrame(tick);
          else {
            node.textContent = raw;
            node.dataset.currentValue = String(target);
            node.dataset.ztLastValue = raw;
            node.dataset.ztAnimating = "0";
          }
        };
        requestAnimationFrame(tick);
      };
      const revealTrace = (node) => {
        if (!node || node.dataset.ztRevealing === "1") return;
        if (node.querySelector && node.querySelector(".zt-trace-step")) return;
        const text = node.textContent || "";
        if (!text || text.length > 3500 || text.includes("<span")) return;
        node.dataset.ztRevealing = "1";
        const lines = text.split("\\n").slice(0, 80);
        node.innerHTML = lines.map((line, index) => {
          const safe = line.replace(/[&<>]/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[ch]));
          return `<span class="zt-trace-step" style="animation-delay:${Math.min(index * 12, 120)}ms">${safe || "&nbsp;"}</span>`;
        }).join("");
        setTimeout(() => { node.dataset.ztRevealing = "0"; }, 320);
      };
      const activeHref = () => {
        const p = (window.location.pathname || "/").replace(/\/$/, "") || "/";
        const aliases = {
          "/chat": "/dashboard/chat",
          "/my-models": "/dashboard/models",
          "/models-manager": "/dashboard/models",
          "/dashboard/registry": "/dashboard/models",
          "/dashboard/soc": "/dashboard/security-monitor",
          "/logs": "/dashboard/security-monitor",
          "/control-plane": "/dashboard/policy",
          "/control-center": "/dashboard/policy",
          "/dashboard/firewall": "/dashboard/policy",
          "/research": "/dashboard/research",
          "/dashboard/models/compare": "/dashboard/research",
          "/dashboard/compare": "/dashboard/research",
          "/dashboard/security": "/dashboard/research",
          "/dashboard/tests": "/dashboard/research",
          "/dashboard/evaluation": "/dashboard/research",
          "/dashboard/evaluate": "/dashboard/research",
          "/dashboard/testing": "/dashboard/research",
          "/dashboard/self-test": "/dashboard/research",
          "/account-security": "/dashboard/account",
          "/my-devices": "/dashboard/account"
        };
        return aliases[p] || p;
      };
      const shouldInjectShell = () => {
        if (document.body && document.body.classList.contains("no-shell")) return false;
        return !["/login", "/signup"].includes(activeHref());
      };
      const topbarTitle = () => {
        const h1 = document.querySelector("h1");
        return (h1 && h1.textContent && h1.textContent.trim()) || "Zero Trust AI Gateway";
      };
      const injectShell = () => {
        if (!shouldInjectShell()) return;
        if (document.getElementById("ztSidebar")) return;
        document.body.classList.add("zt-with-shell");
        const sidebar = document.createElement("aside");
        sidebar.id = "ztSidebar";
        sidebar.className = "zt-sidebar rounded-2xl border border-white/10 bg-slate-950/95 text-slate-100";
        const nav = NAV_ITEMS.map((item) => {
          const isActive = activeHref() === item.href;
          return `<a href="${item.href}" class="${UI.sidebarItem} ${isActive ? UI.sidebarItemActive : ""}"><b>${item.icon}</b><span>${item.label}</span></a>`;
        }).join("");
        sidebar.innerHTML = `
          <div class="zt-brand border-b border-white/10 px-3 pb-3"><b class="text-sm font-semibold text-slate-100">Zero Trust AI Gateway</b><span class="mt-1 block text-xs text-slate-400">Behaviour-aware secure inference</span></div>
          <nav class="zt-nav">${nav}</nav>
          <div class="zt-status">
            <div class="zt-chip"><span class="zt-dot good"></span><span id="ztSysHealth">Gateway online</span></div>
            <div class="zt-chip"><span class="zt-dot warn"></span><span id="ztThreatState">Risk: --</span></div>
          </div>`;
        document.body.appendChild(sidebar);

        const top = document.createElement("section");
        top.id = "ztTopbar";
        top.className = "zt-topbar rounded-2xl border border-white/10 bg-slate-950/90 text-slate-100";
        top.innerHTML = `<h3>${topbarTitle()}</h3><div class="meta"><span class="zt-chip">Behaviour-Aware Secure AI Inference</span><span class="zt-chip" id="ztReqChip">Requests: --</span><span class="zt-chip" id="ztBlockChip">Blocked: --</span></div>`;
        document.body.appendChild(top);
      };
      const refreshTopbarStats = async () => {
        const token = sessionStorage.getItem("zta_token");
        if (!token) return;
        try {
          const res = await fetch("/api/v1/monitoring/metrics", { headers: { Authorization: `Bearer ${token}` } });
          if (!res.ok) return;
          const data = await res.json();
          const req = document.getElementById("ztReqChip");
          const blk = document.getElementById("ztBlockChip");
          const threat = document.getElementById("ztThreatState");
          if (req) req.textContent = `Req: ${data.total_requests ?? 0}`;
          if (blk) blk.textContent = `Blocked: ${data.blocked_requests ?? 0}`;
          if (threat) {
            const level = Number(data.block_rate || 0) >= 40 ? "High" : Number(data.block_rate || 0) >= 15 ? "Medium" : "Low";
            threat.textContent = `Threats: ${level}`;
          }
        } catch {}
      };
      const decorate = (root = document) => {
        if (!root.querySelectorAll) return;
        addClasses(document.body, "bg-slate-950 text-slate-100 antialiased");
        document.querySelectorAll(".shell, .wrap").forEach((node) => addClasses(node, UI.page));
        document.querySelectorAll(".panel, .card, .status-card").forEach((node) => addClasses(node, UI.sectionCard));
        document.querySelectorAll(".stat, .metric, .kpi").forEach((node) => addClasses(node, UI.metricCard));
        document.querySelectorAll("input, textarea, select").forEach((node) => addClasses(node, UI.input));
        document.querySelectorAll("table").forEach((node) => addClasses(node, UI.table));
        document.querySelectorAll(".empty-state, .state, .feed-empty, .empty").forEach((node) => addClasses(node, UI.empty));
        document.querySelectorAll(".badge, .pill, .zt-chip").forEach((node) => addClasses(node, UI.badge));
        document.querySelectorAll(".tab").forEach((node) => addClasses(node, UI.tab));
        document.querySelectorAll(".tab.active").forEach((node) => addClasses(node, "zt-tab-active border-cyan-400/40 bg-cyan-400/10 text-slate-100"));
        document.querySelectorAll("button, a").forEach((node) => {
          if (node.closest(".zt-nav")) return;
          if (node.classList.contains("danger")) addClasses(node, UI.buttonDanger);
          else if (node.classList.contains("secondary")) addClasses(node, UI.buttonSecondary);
          else if (node.classList.contains("tab")) addClasses(node, UI.tab);
          else if (node.matches("button.primary, #sendBtn, .btn-primary")) addClasses(node, UI.buttonPrimary);
          else addClasses(node, UI.buttonSecondary);
        });
        document.querySelectorAll(".badge, .pill").forEach(decorateDecision);
        document.querySelectorAll("#decisionTrace, #simResult").forEach(revealTrace);
        document.querySelectorAll("#logs .card").forEach((node, index) => {
          node.classList.add("zt-log-card");
          node.style.animationDelay = `${Math.min(index * 22, 220)}ms`;
        });
      };
      const observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
          const target = mutation.target;
          if (target.nodeType !== 1) continue;
          if (target.id && numericIds.has(target.id)) animateNumber(target, target.textContent);
          if (target.matches && (target.matches(".badge, .pill") || target.id === "decisionPill" || target.id === "ztaStatus")) decorateDecision(target);
          if (target.id === "decisionTrace" || target.id === "simResult") revealTrace(target);
          mutation.addedNodes.forEach((node) => {
            if (node.nodeType !== 1) return;
            if (node.matches && node.matches(".badge, .pill")) decorateDecision(node);
            if (node.querySelectorAll) node.querySelectorAll(".badge, .pill").forEach(decorateDecision);
            decorate(node);
          });
        }
      });
      window.addEventListener("DOMContentLoaded", () => {
        injectShell();
        document.body.classList.add("zt-ready");
        decorate();
        refreshTopbarStats();
        observer.observe(document.body, { childList: true, subtree: true });
      });
    })();
  </script>
"""
